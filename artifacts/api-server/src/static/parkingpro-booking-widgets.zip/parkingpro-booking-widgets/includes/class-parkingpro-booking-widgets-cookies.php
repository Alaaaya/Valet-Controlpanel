<?php

class ParkingPro_Booking_Widgets_Cookies {
    private static function get_secret_key() {
        if ( defined( 'PARKINGPRO_BOOKING_WIDGETS_COOKIE_KEY' ) ) {
            return PARKINGPRO_BOOKING_WIDGETS_COOKIE_KEY;
        }

        return AUTH_KEY;
    }

    /**
     * @param string $name
     * @param mixed $value
     * @param int $expire
     * @return WP_Error|null
     */
    public static function set_encrypted_cookie( $name, $value, $expire = 0 ) {
        $json = wp_json_encode( $value );

        if ( false === $json ) {
            return new WP_Error( 'json_encode_failed', 'Failed to JSON-encode data.' );
        }

        if ( ParkingPro_Booking_Widgets_Encryption::supports_encryption() ) {
            $data = ParkingPro_Booking_Widgets_Encryption::encrypt( $json, self::get_secret_key() );
        }
        else {
            $data = $json;
        }

        setcookie(
            $name,
            $data,
            [
                'expires'  => $expire,
                'path'     => '/',
                'domain'   => '',
                'secure'   => is_ssl(),
                'httponly' => true,
                'samesite' => 'Strict',
            ]
        );

        return null;
    }

    /**
     * @param string $name
     * @return mixed
     */
    public static function get_encrypted_cookie( $name ) {
        if ( ! isset( $_COOKIE[ $name ] )) {
            return null;
        }

        $blob = wp_unslash( $_COOKIE[ $name ] );

        if ( ParkingPro_Booking_Widgets_Encryption::supports_encryption() ) {
            $json = ParkingPro_Booking_Widgets_Encryption::decrypt( $blob, self::get_secret_key() );
        }
        else {
            $json = $blob;
        }

        if ( null === $json ) {
            return null;
        }

        $data = json_decode( $json, true );
        if ( null === $data && json_last_error() !== JSON_ERROR_NONE ) {
            return null;
        }

        return $data;
    }

    /**
     * @param string $name
     * @return void
     */
    public static function clear_cookie( $name ) {
        setcookie( $name, '', time() - 3600 );
    }
}