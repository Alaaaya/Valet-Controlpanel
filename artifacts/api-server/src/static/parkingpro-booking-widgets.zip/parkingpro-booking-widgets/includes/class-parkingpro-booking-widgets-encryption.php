<?php

class ParkingPro_Booking_Widgets_Encryption {
    public static function supports_encryption() {
        return function_exists( 'openssl_encrypt' );
    } 

    public static function encrypt( $plain_text, $secret ) {
        // Derive separate 256-bit keys for encryption and HMAC
        $enc_key   = hash( 'sha256', $secret . '::enc', true );
        $hmac_key  = hash( 'sha256', $secret . '::hmac', true );

        $iv        = random_bytes(16);
        $cipher    = openssl_encrypt( $plain_text, 'AES-256-CBC', $enc_key, OPENSSL_RAW_DATA, $iv );
        $hmac      = hash_hmac( 'sha256', $iv . $cipher, $hmac_key, true );

        return base64_encode( $iv . $hmac . $cipher );
    }

    public static function decrypt( $blob, $secret ) {
        $data = base64_decode( $blob, true );

        if ( $data === false || strlen( $data ) < 48 ) {
            return null;
        }

        $iv        = substr( $data, 0, 16 );
        $hmac      = substr( $data, 16, 32 );
        $cipher    = substr( $data, 48 );

        $enc_key   = hash( 'sha256', $secret . '::enc',  true );
        $hmac_key  = hash( 'sha256', $secret . '::hmac', true );

        // timing-safe compare
        if ( ! hash_equals( hash_hmac( 'sha256', $iv . $cipher, $hmac_key, true ), $hmac ) ) {
            return null;
        }

        return openssl_decrypt( $cipher, 'AES-256-CBC', $enc_key, OPENSSL_RAW_DATA, $iv );
    }
}