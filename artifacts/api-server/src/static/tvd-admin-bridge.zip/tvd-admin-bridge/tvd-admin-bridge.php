<?php
/**
 * Plugin Name: TVD Admin Bridge
 * Description: Bridge between TVD Admin Panel and WordPress
 * Version: 2.0.8
 * Author: Travel Valet Dusseldorf
 * Requires PHP: 7.0
 */

if (!defined('ABSPATH')) { exit; }

/* REST routes */
if (!function_exists('tvd_register_routes')) {
    function tvd_register_routes() {
        register_rest_route('tvd-admin/v1', '/sections', array(
            array('methods'=>'GET',  'callback'=>'tvd_rest_get_sections',  'permission_callback'=>'__return_true'),
            array('methods'=>'POST', 'callback'=>'tvd_rest_save_sections', 'permission_callback'=>'tvd_rest_is_admin'),
        ));
        register_rest_route('tvd-admin/v1', '/parkingpro', array(
            array('methods'=>'GET',  'callback'=>'tvd_rest_get_pp',  'permission_callback'=>'__return_true'),
            array('methods'=>'POST', 'callback'=>'tvd_rest_save_pp', 'permission_callback'=>'tvd_rest_is_admin'),
        ));
        register_rest_route('tvd-admin/v1', '/booking-prices', array(
            array('methods'=>'GET',  'callback'=>'tvd_rest_get_booking_prices',  'permission_callback'=>'__return_true'),
            array('methods'=>'POST', 'callback'=>'tvd_rest_save_booking_prices', 'permission_callback'=>'tvd_rest_is_admin'),
        ));
        register_rest_route('tvd-admin/v1', '/logo', array(
            array('methods'=>'GET',  'callback'=>'tvd_rest_get_logo',  'permission_callback'=>'__return_true'),
            array('methods'=>'POST', 'callback'=>'tvd_rest_save_logo', 'permission_callback'=>'tvd_rest_is_admin'),
        ));
        register_rest_route('tvd-admin/v1', '/booking-email', array(
            array('methods'=>'GET',  'callback'=>'tvd_rest_get_email',  'permission_callback'=>'tvd_rest_is_admin'),
            array('methods'=>'POST', 'callback'=>'tvd_rest_save_email', 'permission_callback'=>'tvd_rest_is_admin'),
        ));
    }
}

/* Activation */
if (!function_exists('tvd_activate')) {
    function tvd_activate() {
        if (get_option('tvd_sections', null) === null) {
            $defaults = '[{"id":"home","label":"Home","visible":true,"order":0},{"id":"tvd-stats","label":"Stats","visible":true,"order":1},{"id":"buchen","label":"Buchen","visible":true,"order":2},{"id":"services","label":"Services","visible":true,"order":3},{"id":"ablauf","label":"Ablauf","visible":true,"order":4},{"id":"parkingpro","label":"ParkingPro","visible":true,"order":5},{"id":"ueber-uns","label":"Ueber uns","visible":true,"order":6},{"id":"kontakt","label":"Kontakt","visible":true,"order":7}]';
            update_option('tvd_sections', $defaults);
        }
    }
}
register_activation_hook(__FILE__, 'tvd_activate');

add_action('rest_api_init', 'tvd_register_routes');

if (!function_exists('tvd_rest_is_admin')) {
    function tvd_rest_is_admin() {
        return current_user_can('manage_options');
    }
}

if (!function_exists('tvd_rest_get_sections')) {
    function tvd_rest_get_sections() {
        $saved = get_option('tvd_sections', null);
        $def = array(
            array('id'=>'home',       'label'=>'Home',       'visible'=>true,  'order'=>0),
            array('id'=>'tvd-stats',  'label'=>'Stats',      'visible'=>true,  'order'=>1),
            array('id'=>'buchen',     'label'=>'Buchen',     'visible'=>true,  'order'=>2),
            array('id'=>'services',   'label'=>'Services',   'visible'=>true,  'order'=>3),
            array('id'=>'ablauf',     'label'=>'Ablauf',     'visible'=>true,  'order'=>4),
            array('id'=>'parkingpro', 'label'=>'ParkingPro', 'visible'=>true,  'order'=>5),
            array('id'=>'ueber-uns',  'label'=>'Ueber uns',  'visible'=>true,  'order'=>6),
            array('id'=>'kontakt',    'label'=>'Kontakt',    'visible'=>true,  'order'=>7),
        );
        return new WP_REST_Response(array(
            'sections' => ($saved !== null) ? json_decode($saved, true) : $def,
            'saved'    => ($saved !== null),
        ));
    }
}

if (!function_exists('tvd_rest_save_sections')) {
    function tvd_rest_save_sections($req) {
        update_option('tvd_sections', json_encode($req->get_param('sections')));
        return new WP_REST_Response(array('ok'=>true));
    }
}

if (!function_exists('tvd_rest_get_pp')) {
    function tvd_rest_get_pp() {
        return new WP_REST_Response(array('embed'=>get_option('tvd_parkingpro_embed','')));
    }
}

if (!function_exists('tvd_rest_save_pp')) {
    function tvd_rest_save_pp($req) {
        update_option('tvd_parkingpro_embed', $req->get_param('embed'));
        return new WP_REST_Response(array('ok'=>true));
    }
}

/* Booking Prices — stored in cents, e.g. freiflaeche=1200 means EUR 12.00/day */
if (!function_exists('tvd_booking_prices_defaults')) {
    function tvd_booking_prices_defaults() {
        return array('freiflaeche'=>1200,'parkhaus'=>1500,'reinigung_aussen'=>4000,'reinigung_innen'=>7000);
    }
}

if (!function_exists('tvd_rest_get_booking_prices')) {
    function tvd_rest_get_booking_prices() {
        $raw = get_option('tvd_booking_prices', null);
        if (!$raw) {
            return new WP_REST_Response(tvd_booking_prices_defaults());
        }
        return new WP_REST_Response(array_merge(tvd_booking_prices_defaults(), json_decode($raw, true)));
    }
}

if (!function_exists('tvd_rest_save_booking_prices')) {
    function tvd_rest_save_booking_prices($req) {
        $body = $req->get_json_params();
        $clean = array(
            'freiflaeche'     => max(100, min(100000, (int)($body['freiflaeche'] ?? 1200))),
            'parkhaus'        => max(100, min(100000, (int)($body['parkhaus'] ?? 1500))),
            'reinigung_aussen'=> max(0,   min(100000, (int)($body['reinigung_aussen'] ?? 4000))),
            'reinigung_innen' => max(0,   min(100000, (int)($body['reinigung_innen'] ?? 7000))),
        );
        update_option('tvd_booking_prices', json_encode($clean));
        return new WP_REST_Response(array('ok'=>true,'saved'=>$clean));
    }
}

if (!function_exists('tvd_rest_get_logo')) {
    function tvd_rest_get_logo() {
        return new WP_REST_Response(array('type'=>get_option('tvd_logo_type','svg'),'url'=>get_option('tvd_logo_url',''),'size'=>(int)get_option('tvd_logo_size',40),'offset_x'=>(int)get_option('tvd_logo_offset_x',0),'offset_y'=>(int)get_option('tvd_logo_offset_y',0)));
    }
}

if (!function_exists('tvd_rest_save_logo')) {
    function tvd_rest_save_logo($req) {
        update_option('tvd_logo_type', $req->get_param('type'));
        update_option('tvd_logo_url',  $req->get_param('url'));
        if($req->get_param('size') !== null) update_option('tvd_logo_size', max(16, min(120, (int)$req->get_param('size'))));
        if($req->get_param('offset_x') !== null) update_option('tvd_logo_offset_x', max(-100, min(100, (int)$req->get_param('offset_x'))));
        if($req->get_param('offset_y') !== null) update_option('tvd_logo_offset_y', max(-50, min(50, (int)$req->get_param('offset_y'))));
        return new WP_REST_Response(array('ok'=>true));
    }
}

if (!function_exists('tvd_rest_get_email')) {
    function tvd_rest_get_email() {
        return new WP_REST_Response(array(
            'enabled'  => (bool) get_option('tvd_booking_email_enabled', 1),
            'subject'  => get_option('tvd_booking_email_subject', 'Buchungsbestatigung - Travel Valet Dusseldorf'),
            'reply_to' => get_option('tvd_booking_email_reply', get_option('admin_email', '')),
        ));
    }
}

if (!function_exists('tvd_rest_save_email')) {
    function tvd_rest_save_email($req) {
        update_option('tvd_booking_email_enabled', ($req->get_param('enabled') ? 1 : 0));
        $s = $req->get_param('subject');
        if (!empty($s)) { update_option('tvd_booking_email_subject', sanitize_text_field($s)); }
        $r = $req->get_param('reply_to');
        if (!empty($r)) { update_option('tvd_booking_email_reply', sanitize_email($r)); }
        return new WP_REST_Response(array('ok'=>true));
    }
}

/* Booking email capture */
if (!function_exists('tvd_ajax_capture')) {
    function tvd_ajax_capture() {
        if (!get_option('tvd_booking_email_enabled', 1)) { return; }
        if (empty($_POST['email'])) { return; }
        if (!is_email(trim($_POST['email']))) { return; }
        $GLOBALS['tvd_post'] = $_POST;
        register_shutdown_function('tvd_ajax_send');
    }
}
add_action('wp_ajax_nopriv_tvd_pl_submit_booking', 'tvd_ajax_capture', 1);

if (!function_exists('tvd_ajax_send')) {
    function tvd_ajax_send() {
        if (empty($GLOBALS['tvd_post'])) { return; }
        $p        = $GLOBALS['tvd_post'];
        $email    = sanitize_email($p['email']);
        $vorname  = sanitize_text_field(isset($p['vorname'])  ? $p['vorname']  : '');
        $nachname = sanitize_text_field(isset($p['nachname']) ? $p['nachname'] : '');
        $anreise  = sanitize_text_field(isset($p['anreise'])  ? $p['anreise']  : '');
        $ankunft  = sanitize_text_field(isset($p['ankunft'])  ? $p['ankunft']  : '');
        $abreise  = sanitize_text_field(isset($p['abreise'])  ? $p['abreise']  : '');
        $lande    = sanitize_text_field(isset($p['lande'])    ? $p['lande']    : '');
        $parkart  = sanitize_text_field(isset($p['parkart'])  ? $p['parkart']  : '');
        $kfz      = sanitize_text_field(isset($p['kfz'])      ? $p['kfz']      : '');
        $modell   = sanitize_text_field(isset($p['modell'])   ? $p['modell']   : '');
        $days     = (int)(isset($p['days'])  ? $p['days']  : 0);
        $price    = number_format((float)(isset($p['price']) ? $p['price'] : 0), 2, ',', '.');
        $zahlung  = sanitize_text_field(isset($p['zahlung'])  ? $p['zahlung']  : '');
        $name     = trim($vorname . ' ' . $nachname);
        if (empty($name)) { $name = 'Kunde'; }
        $ref  = 'TVD-' . strtoupper(substr(md5($email . $anreise . (string)time()), 0, 8));
        $pl   = ($parkart === 'freiflaeche') ? 'Freiflaeche' : 'Parkhaus';
        $zl   = ($zahlung === 'online') ? 'Online' : 'Bar bei Uebergabe';
        $dl   = $days . ($days !== 1 ? ' Tage' : ' Tag');
        $rows = array(
            array('Anreise',     $anreise . ' um ' . $ankunft . ' Uhr'),
            array('Abreise',     $abreise . ' um ' . $lande   . ' Uhr'),
            array('Dauer',       $dl),
            array('Parkart',     $pl),
            array('Kennzeichen', $kfz),
            array('Fahrzeug',    $modell),
            array('Zahlung',     $zl),
            array('Preis',       'EUR ' . $price),
        );
        $tb = '';
        $i  = 0;
        foreach ($rows as $row) {
            $bg  = ($i % 2 === 0) ? '#fff' : '#f8f9fc';
            $tb .= '<tr style="background:' . $bg . ';">'
                . '<td style="padding:10px 14px;color:#6b7a99;font-size:13px;">' . esc_html($row[0]) . '</td>'
                . '<td style="padding:10px 14px;color:#1a2035;font-size:13px;font-weight:600;text-align:right;">' . esc_html($row[1]) . '</td>'
                . '</tr>';
            $i++;
        }
        $html = '<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8"></head>'
            . '<body style="margin:0;padding:20px;background:#f4f6f9;font-family:Arial,sans-serif;">'
            . '<div style="max-width:580px;margin:auto;background:#fff;border-radius:12px;overflow:hidden;">'
            . '<div style="background:#0b0f1a;padding:28px 32px;text-align:center;">'
            . '<div style="color:#c9a84c;font-size:20px;font-weight:700;">Travel Valet Dusseldorf</div>'
            . '<div style="color:#8b9bb4;font-size:12px;margin-top:4px;">Valet Parken am Flughafen DUS</div>'
            . '</div>'
            . '<div style="background:#c9a84c;padding:12px 32px;text-align:center;">'
            . '<div style="color:#0b0f1a;font-size:16px;font-weight:700;">Buchung bestatigt</div>'
            . '<div style="color:#0b0f1a;font-size:11px;">' . esc_html($ref) . '</div>'
            . '</div>'
            . '<div style="padding:24px 32px;">'
            . '<p style="margin:0;color:#1a2035;">Guten Tag, <strong>' . esc_html($name) . '</strong>,</p>'
            . '<p style="margin:10px 0 0;color:#4b5675;font-size:14px;line-height:1.6;">vielen Dank fuer Ihre Buchung. Unser Fahrer wartet zum vereinbarten Zeitpunkt am Terminal.</p>'
            . '</div>'
            . '<div style="padding:0 32px 24px;">'
            . '<table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e8ecf4;border-radius:8px;overflow:hidden;">'
            . $tb
            . '</table></div>'
            . '<div style="background:#f8f9fc;padding:16px 32px;text-align:center;border-top:1px solid #e8ecf4;font-size:11px;color:#8b9bb4;">'
            . 'Travel Valet Dusseldorf &middot; info.travelpark24@gmail.com'
            . '</div></div></body></html>';
        $subject = get_option('tvd_booking_email_subject', 'Buchungsbestatigung - Travel Valet Dusseldorf');
        $reply   = get_option('tvd_booking_email_reply', get_option('admin_email', ''));
        $headers = array('Content-Type: text/html; charset=UTF-8', 'Reply-To: ' . $reply);
        wp_mail($email, $subject, $html, $headers);
    }
}

/* Frontend JS */
if (!function_exists('tvd_footer_js')) {
    function tvd_footer_js() {
        $sr  = get_option('tvd_sections', null);
        $sj  = ($sr !== null) ? $sr : '[]';
        $lu  = json_encode(get_option('tvd_logo_url', ''));
        $lt  = json_encode(get_option('tvd_logo_type', ''));
        $ls  = (int)get_option('tvd_logo_size', 40);
        $lox = (int)get_option('tvd_logo_offset_x', 0);
        $loy = (int)get_option('tvd_logo_offset_y', 0);
        $pp  = json_encode(get_option('tvd_parkingpro_embed', ''));
        $bpRaw = get_option('tvd_booking_prices', null);
        $bp  = $bpRaw ? array_merge(tvd_booking_prices_defaults(), json_decode($bpRaw, true)) : tvd_booking_prices_defaults();
        $bpF  = (int)$bp['freiflaeche'];
        $bpP  = (int)$bp['parkhaus'];
        $bpRA = (int)$bp['reinigung_aussen'];
        $bpRI = (int)$bp['reinigung_innen'];
        ?>
<script>
(function(){
/* Tag elements that exist in the page but lack an id */
(function tagElems(){
  var tags=[
    {sel:'.tvd-stats',   id:'tvd-stats'},
    {sel:'.tvd-footer',  id:'tvd-footer'},
    {sel:'footer',       id:'tvd-footer'}
  ];
  tags.forEach(function(t){
    var el=document.querySelector(t.sel);
    if(el&&!el.id){el.id=t.id;}
  });
})();
var S=<?php echo $sj; ?>;
if(S&&S.length){
  var sorted=S.slice().sort(function(a,b){return(a.order||0)-(b.order||0);});
  var els=sorted.map(function(s){return document.getElementById(s.id);}).filter(Boolean);
  if(els.length>0){var par=els[0].parentNode;if(par){els.forEach(function(el){par.appendChild(el);});}}
  sorted.forEach(function(s){var e=document.getElementById(s.id);if(e)e.style.display=s.visible?"":"none";});
}
var lt=<?php echo $lt; ?>,lu=<?php echo $lu; ?>;
if(lt==="url"&&lu){var br=document.querySelector("#tvd-nav .tvd-logo");if(!br)br=document.querySelector(".tvd-logo");if(br&&!br.querySelector(".tvd-li")){br.style.cssText+=";display:inline-flex!important;align-items:center!important;gap:8px!important;text-decoration:none;";var im=document.createElement("img");im.src=lu;im.style.cssText="height:"+<?php echo $ls; ?>+"px;width:auto;object-fit:contain;flex-shrink:0;display:block;transform:translate("+<?php echo $lox; ?>+"px,"+<?php echo $loy; ?>+"px);";im.className="tvd-li";br.insertBefore(im,br.firstChild);}}
var pp=<?php echo $pp; ?>;
if(pp){var ps=document.getElementById("parkingpro");if(!ps){ps=document.createElement("section");ps.id="parkingpro";document.body.appendChild(ps);}ps.innerHTML="<div style='padding:60px 20px;text-align:center'>"+pp+"</div>";}
/* Booking prices override */
(function(){
  var pF=<?php echo $bpF; ?>,pP=<?php echo $bpP; ?>,pRA=<?php echo $bpRA; ?>,pRI=<?php echo $bpRI; ?>;
  function setInp(id,val){var el=document.getElementById(id);if(el)el.value=val;}
  setInp('tvd_pF',pF);setInp('tvd_pP',pP);setInp('tvd_pRA',pRA);setInp('tvd_pRI',pRI);
  /* Update visible price labels */
  function fmtEur(cents){return '\u20ac'+(cents/100).toFixed(0);}
  var opts=document.querySelectorAll('.tvd-parkart-opt');
  if(opts.length>=2){
    var sp0=opts[0].querySelector('span:last-child');if(sp0)sp0.textContent=fmtEur(pF)+'/Tag';
    var sp1=opts[1].querySelector('span:last-child');if(sp1)sp1.textContent=fmtEur(pP)+'/Tag';
  }
  var reinOpts=document.querySelectorAll('.tvd-rein-opt');
  if(reinOpts.length>=2){
    var rsp0=reinOpts[0].querySelector('span:last-child');if(rsp0)rsp0.textContent=fmtEur(pRA);
    var rsp1=reinOpts[1].querySelector('span:last-child');if(rsp1)rsp1.textContent=fmtEur(pRI);
  }
})();
})();
</script>
        <?php
    }
}
add_action('wp_footer', 'tvd_footer_js', 99);
