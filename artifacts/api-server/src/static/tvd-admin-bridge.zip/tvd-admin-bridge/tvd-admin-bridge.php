<?php
/**
 * Plugin Name: TVD Admin Bridge
 * Description: Bridge between TVD Admin Panel and WordPress
 * Version: 1.7.1
 * Author: Travel Valet Düsseldorf
 */

if (!defined('ABSPATH')) exit;

/* ─── REST API ───────────────────────────────────────────────────────────── */
add_action('rest_api_init', function () {
    register_rest_route('tvd-admin/v1', '/sections', array(
        array('methods'=>'GET',  'callback'=>'tvd_get_sections',  'permission_callback'=>'__return_true'),
        array('methods'=>'POST', 'callback'=>'tvd_save_sections', 'permission_callback'=>'tvd_auth'),
    ));
    register_rest_route('tvd-admin/v1', '/parkingpro', array(
        array('methods'=>'GET',  'callback'=>'tvd_get_parkingpro',  'permission_callback'=>'__return_true'),
        array('methods'=>'POST', 'callback'=>'tvd_save_parkingpro', 'permission_callback'=>'tvd_auth'),
    ));
    register_rest_route('tvd-admin/v1', '/logo', array(
        array('methods'=>'GET',  'callback'=>'tvd_get_logo',  'permission_callback'=>'__return_true'),
        array('methods'=>'POST', 'callback'=>'tvd_save_logo', 'permission_callback'=>'tvd_auth'),
    ));
    register_rest_route('tvd-admin/v1', '/booking-email', array(
        array('methods'=>'GET',  'callback'=>'tvd_get_booking_email',  'permission_callback'=>'tvd_auth'),
        array('methods'=>'POST', 'callback'=>'tvd_save_booking_email', 'permission_callback'=>'tvd_auth'),
    ));
});

function tvd_auth() {
    $h = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
    if (!$h && function_exists('getallheaders')) {
        $all = getallheaders();
        $h = isset($all['Authorization']) ? $all['Authorization'] : (isset($all['authorization']) ? $all['authorization'] : '');
    }
    if (substr($h, 0, 6) !== 'Basic ') return false;
    $parts = explode(':', base64_decode(substr($h, 6)), 2);
    return isset($parts[0], $parts[1]) && $parts[0] === get_option('tvd_wp_user') && $parts[1] === get_option('tvd_wp_pass');
}

function tvd_get_sections() {
    $def = array(
        array('id'=>'home',       'label'=>'القسم الرئيسي',                      'visible'=>true,'order'=>0),
        array('id'=>'tvd-stats',  'label'=>'الإحصائيات','visible'=>true,'order'=>1),
        array('id'=>'buchen',     'label'=>'الحجز',     'visible'=>true,'order'=>2),
        array('id'=>'services',   'label'=>'الخدمات',   'visible'=>true,'order'=>3),
        array('id'=>'ablauf',     'label'=>'كيف يعمل',  'visible'=>true,'order'=>4),
        array('id'=>'parkingpro', 'label'=>'ParkingPro','visible'=>true,'order'=>5),
        array('id'=>'ueber-uns',  'label'=>'من نحن',    'visible'=>true,'order'=>6),
        array('id'=>'kontakt',    'label'=>'تواصل معنا','visible'=>true,'order'=>7),
    );
    $saved = get_option('tvd_sections', null);
    return new WP_REST_Response(array(
        'sections' => $saved !== null ? json_decode($saved, true) : $def,
        'saved'    => $saved !== null,
    ));
}
function tvd_save_sections($req) {
    update_option('tvd_sections', json_encode($req->get_param('sections')));
    return new WP_REST_Response(array('ok'=>true));
}
function tvd_get_parkingpro() {
    return new WP_REST_Response(array('embed'=>get_option('tvd_parkingpro_embed', '')));
}
function tvd_save_parkingpro($req) {
    update_option('tvd_parkingpro_embed', $req->get_param('embed'));
    return new WP_REST_Response(array('ok'=>true));
}
function tvd_get_logo() {
    return new WP_REST_Response(array(
        'type' => get_option('tvd_logo_type', 'svg'),
        'url'  => get_option('tvd_logo_url', ''),
    ));
}
function tvd_save_logo($req) {
    update_option('tvd_logo_type', $req->get_param('type'));
    update_option('tvd_logo_url',  $req->get_param('url'));
    return new WP_REST_Response(array('ok'=>true));
}
function tvd_get_booking_email() {
    return new WP_REST_Response(array(
        'enabled'  => (bool) get_option('tvd_booking_email_enabled', 1),
        'subject'  => get_option('tvd_booking_email_subject', 'Buchungsbestätigung – Travel Valet Düsseldorf'),
        'reply_to' => get_option('tvd_booking_email_reply', get_option('admin_email')),
    ));
}
function tvd_save_booking_email($req) {
    update_option('tvd_booking_email_enabled', $req->get_param('enabled') ? 1 : 0);
    $s = $req->get_param('subject');  if ($s) update_option('tvd_booking_email_subject', sanitize_text_field($s));
    $r = $req->get_param('reply_to'); if ($r) update_option('tvd_booking_email_reply',   sanitize_email($r));
    return new WP_REST_Response(array('ok'=>true));
}

/* ─── AJAX: Customer confirmation email ──────────────────────────────────── */
add_action('wp_ajax_nopriv_tvd_bridge_send_confirm', 'tvd_handle_confirm');
add_action('wp_ajax_tvd_bridge_send_confirm',        'tvd_handle_confirm');
function tvd_handle_confirm() {
    if (!get_option('tvd_booking_email_enabled', 1)) { wp_send_json_success(); return; }
    $email = sanitize_email(isset($_POST['email']) ? $_POST['email'] : '');
    if (!$email || !is_email($email)) { wp_send_json_error('invalid email'); return; }

    $vorname  = sanitize_text_field(isset($_POST['vorname'])  ? $_POST['vorname']  : '');
    $nachname = sanitize_text_field(isset($_POST['nachname']) ? $_POST['nachname'] : '');
    $anreise  = sanitize_text_field(isset($_POST['anreise'])  ? $_POST['anreise']  : '');
    $ankunft  = sanitize_text_field(isset($_POST['ankunft'])  ? $_POST['ankunft']  : '');
    $abreise  = sanitize_text_field(isset($_POST['abreise'])  ? $_POST['abreise']  : '');
    $lande    = sanitize_text_field(isset($_POST['lande'])    ? $_POST['lande']    : '');
    $parkart  = sanitize_text_field(isset($_POST['parkart'])  ? $_POST['parkart']  : '');
    $kfz      = sanitize_text_field(isset($_POST['kfz'])      ? $_POST['kfz']      : '');
    $modell   = sanitize_text_field(isset($_POST['modell'])   ? $_POST['modell']   : '');
    $rein     = sanitize_text_field(isset($_POST['rein'])     ? $_POST['rein']     : 'keine');
    $days     = (int)(isset($_POST['days'])  ? $_POST['days']  : 0);
    $price    = number_format((float)(isset($_POST['price']) ? $_POST['price'] : 0), 2, ',', '.');
    $zahlung  = sanitize_text_field(isset($_POST['zahlung'])  ? $_POST['zahlung']  : '');

    $name  = trim($vorname . ' ' . $nachname);
    if (!$name) $name = 'Kunde';
    $ref   = 'TVD-' . strtoupper(substr(md5($email . $anreise . time()), 0, 8));
    $pl    = ($parkart === 'freiflaeche') ? 'Freiflächenpark' : 'Parkhaus (überdacht)';
    $zl    = ($zahlung === 'online') ? 'Online (Zahlungslink per E-Mail)' : 'Bar bei Übergabe';
    $rl_a  = array();
    if (strpos($rein, 'aussen') !== false) $rl_a[] = 'Außenreinigung';
    if (strpos($rein, 'innen')  !== false) $rl_a[] = 'Innenreinigung';
    $rl    = $rl_a ? implode(' + ', $rl_a) : 'Keine';
    $dt    = $days . ' Tag' . ($days !== 1 ? 'e' : '');

    $rows = array(
        array('Anreise',    $anreise . ' um ' . $ankunft . ' Uhr'),
        array('Abreise',    $abreise . ' um ' . $lande   . ' Uhr'),
        array('Dauer',      $dt),
        array('Parkart',    $pl),
        array('Kennzeichen',$kfz),
        array('Fahrzeug',   $modell),
        array('Reinigung',  $rl),
        array('Zahlung',    $zl),
        array('Preis',      'EUR ' . $price),
    );
    $tbody = '';
    foreach ($rows as $i => $row) {
        $bg = ($i % 2 === 0) ? '#ffffff' : '#f8f9fc';
        $tbody .= '<tr style="background:' . $bg . ';">'
            . '<td style="padding:10px 14px;color:#6b7a99;font-size:13px;white-space:nowrap;">' . esc_html($row[0]) . '</td>'
            . '<td style="padding:10px 14px;color:#1a2035;font-size:13px;font-weight:600;text-align:right;">' . esc_html($row[1]) . '</td>'
            . '</tr>';
    }

    $html = '<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8"></head>'
        . '<body style="margin:0;padding:0;background:#f4f6f9;font-family:Arial,sans-serif;">'
        . '<table width="100%" cellpadding="0" cellspacing="0" style="padding:32px 16px;"><tr><td align="center">'
        . '<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#fff;border-radius:16px;overflow:hidden;">'
        . '<tr><td style="background:#0b0f1a;padding:32px 40px;text-align:center;">'
        . '<div style="color:#c9a84c;font-size:22px;font-weight:700;">Travel Valet Dusseldorf</div>'
        . '<div style="color:#8b9bb4;font-size:13px;margin-top:4px;">Valet Parken am Flughafen DUS</div>'
        . '</td></tr>'
        . '<tr><td style="background:#c9a84c;padding:14px 40px;text-align:center;">'
        . '<div style="color:#0b0f1a;font-size:17px;font-weight:700;">Buchung bestatigt</div>'
        . '<div style="color:#0b0f1a;font-size:12px;margin-top:2px;">Ref: ' . esc_html($ref) . '</div>'
        . '</td></tr>'
        . '<tr><td style="padding:28px 40px 12px;">'
        . '<p style="margin:0;color:#1a2035;font-size:15px;">Guten Tag, <strong>' . esc_html($name) . '</strong>,</p>'
        . '<p style="margin:10px 0 0;color:#4b5675;font-size:14px;line-height:1.6;">vielen Dank fuer Ihre Buchung! Unser Fahrer wird zum vereinbarten Zeitpunkt am Terminal auf Sie warten.</p>'
        . '</td></tr>'
        . '<tr><td style="padding:8px 40px 28px;">'
        . '<div style="border:1px solid #e8ecf4;border-radius:10px;overflow:hidden;">'
        . '<table width="100%" cellpadding="0" cellspacing="0">' . $tbody . '</table>'
        . '</div></td></tr>'
        . '<tr><td style="padding:0 40px 28px;">'
        . '<div style="background:#fffbf0;border:1px solid #f0d080;border-radius:10px;padding:18px;font-size:13px;color:#7a6020;line-height:1.6;">'
        . '<strong>Treffpunkt:</strong> Terminal Flughafen Dusseldorf (DUS) - Fahrer haelt Schild mit Ihrem Namen.<br><br>'
        . '<strong>Fragen?</strong> info.travelpark24@gmail.com'
        . '</div></td></tr>'
        . '<tr><td style="background:#f8f9fc;padding:20px 40px;text-align:center;border-top:1px solid #e8ecf4;">'
        . '<div style="font-size:12px;color:#8b9bb4;">Travel Valet Dusseldorf &middot; info.travelpark24@gmail.com</div>'
        . '</td></tr>'
        . '</table></td></tr></table></body></html>';

    $subject = get_option('tvd_booking_email_subject', 'Buchungsbestatigung - Travel Valet Dusseldorf');
    $reply   = get_option('tvd_booking_email_reply',   get_option('admin_email'));
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'Reply-To: ' . $reply,
        'From: Travel Valet Dusseldorf <' . get_option('admin_email') . '>',
    );
    wp_mail($email, $subject, $html, $headers);
    wp_send_json_success();
}

/* ─── Frontend injection (only applies saved settings) ───────────────────── */
add_action('wp_footer', 'tvd_inject_frontend', 99);
function tvd_inject_frontend() {
    /* Sections: only apply if admin has explicitly saved settings */
    $sections_raw = get_option('tvd_sections', null);
    $sections_js  = ($sections_raw !== null) ? $sections_raw : '[]';

    /* Logo: only inject if admin explicitly saved a custom URL */
    $logo_url  = get_option('tvd_logo_url', '');
    $logo_type = get_option('tvd_logo_type', '');

    /* ParkingPro: only inject if embed code is set */
    $pp_embed = get_option('tvd_parkingpro_embed', '');

    /* Confirmation email */
    $ajax_url = admin_url('admin-ajax.php');
    $email_on = get_option('tvd_booking_email_enabled', 1) ? 'true' : 'false';

    $sj = $sections_js;
    $lu = json_encode($logo_url);
    $lt = json_encode($logo_type);
    $pp = json_encode($pp_embed);
    $aj = json_encode($ajax_url);

    echo '<script>' . "\n";
    echo '(function(){' . "\n";

    /* --- Sections visibility & order (only if explicitly saved) --- */
    echo 'var S=' . $sj . ';';
    echo 'if(S&&S.length){';
    echo '  S.forEach(function(s){var e=document.getElementById(s.id);if(e)e.style.display=s.visible?"":"none";});';
    echo '  var visible=S.filter(function(s){return s.visible;});';
    echo '  visible.sort(function(a,b){return(a.order||0)-(b.order||0);});';
    echo '  var elems=visible.map(function(s){return document.getElementById(s.id);}).filter(Boolean);';
    echo '  if(elems.length>1){var ref=elems[0];var par=ref.parentNode;if(par){';
    echo '    elems.forEach(function(el){par.insertBefore(el,par.lastChild.nextSibling);});';
    echo '  }}';
    echo '}' . "\n";

    /* --- Logo: only if URL type and URL is set --- */
    echo 'var lt=' . $lt . ',lu=' . $lu . ';';
    echo 'if(lt==="url"&&lu){';
    echo '  var br=document.querySelector(".navbar-brand,.tvd-logo,[class*=\'brand\']");';
    echo '  if(br&&!br.querySelector(".tvd-logo-injected")){';
    echo '    var im=document.createElement("img");im.src=lu;im.style.cssText="height:36px;width:auto;vertical-align:middle;margin-left:8px;";im.className="tvd-logo-injected";';
    echo '    br.insertBefore(im,br.firstChild);';
    echo '  }';
    echo '}' . "\n";

    /* --- ParkingPro: only if embed is set --- */
    echo 'var pp=' . $pp . ';';
    echo 'if(pp){';
    echo '  var ps=document.getElementById("parkingpro");';
    echo '  if(!ps){ps=document.createElement("section");ps.id="parkingpro";document.body.appendChild(ps);}';
    echo '  ps.innerHTML=\'<div style="padding:60px 20px;text-align:center;">\'+pp+\'</div>\';';
    echo '}' . "\n";

    /* --- Confirmation email wrap --- */
    echo 'var tvdAjax=' . $aj . ';';
    echo 'var emailOn=' . $email_on . ';';
    echo 'if(emailOn&&typeof window.tvdSubmit==="function"){';
    echo '  var _orig=window.tvdSubmit;';
    echo '  window.tvdSubmit=function(){';
    echo '    var _fetch=window.fetch;';
    echo '    window.fetch=function(url,opts){';
    echo '      return _fetch.call(window,url,opts).then(function(r){';
    echo '        var cl=r.clone();';
    echo '        cl.json().then(function(res){';
    echo '          if(res&&res.success){';
    echo '            var fd=new FormData();';
    echo '            fd.append("action","tvd_bridge_send_confirm");';
    echo '            var g=function(id){var e=document.getElementById(id);return e?e.value:"";};';
    echo '            fd.append("email",g("tvd_email"));';
    echo '            fd.append("vorname",g("tvd_vorname"));';
    echo '            fd.append("nachname",g("tvd_nachname"));';
    echo '            fd.append("anreise",g("tvd_anreise"));';
    echo '            fd.append("ankunft",g("tvd_ankunft"));';
    echo '            fd.append("abreise",g("tvd_abreise"));';
    echo '            fd.append("lande",g("tvd_lande"));';
    echo '            fd.append("kfz",g("tvd_kennzeichen"));';
    echo '            fd.append("modell",g("tvd_modell"));';
    echo '            if(typeof parkart!=="undefined")fd.append("parkart",parkart);';
    echo '            if(typeof rein_a!=="undefined"){var ri=[];if(rein_a)ri.push("aussen");if(typeof rein_i!=="undefined"&&rein_i)ri.push("innen");fd.append("rein",ri.join("+"));}';
    echo '            if(typeof calcPrice==="function"){var cp=calcPrice();if(cp){fd.append("days",cp.days||0);fd.append("price",(cp.total||0).toFixed(2));}}';
    echo '            if(typeof payOpt!=="undefined")fd.append("zahlung",payOpt);';
    echo '            _fetch.call(window,tvdAjax,{method:"POST",body:fd}).catch(function(){});';
    echo '          }';
    echo '          window.fetch=_fetch;';
    echo '        }).catch(function(){window.fetch=_fetch;});';
    echo '        return r;';
    echo '      }).catch(function(e){window.fetch=_fetch;throw e;});';
    echo '    };';
    echo '    _orig();';
    echo '  };';
    echo '}' . "\n";

    echo '})();' . "\n";
    echo '</script>' . "\n";
}
