<?php
/**
 * Plugin Name: TVD Admin Bridge
 * Description: Bridge between TVD Admin Panel and WordPress
 * Version: 1.6.0
 * Author: Travel Valet Düsseldorf
 */

if (!defined('ABSPATH')) exit;

/* ──────────────────────────────────────────────
   REST API — Sections
────────────────────────────────────────────── */
add_action('rest_api_init', function () {

    register_rest_route('tvd-admin/v1', '/sections', [
        ['methods' => 'GET', 'callback' => 'tvd_get_sections', 'permission_callback' => '__return_true'],
        ['methods' => 'POST', 'callback' => 'tvd_save_sections', 'permission_callback' => 'tvd_auth'],
    ]);

    register_rest_route('tvd-admin/v1', '/parkingpro', [
        ['methods' => 'GET', 'callback' => 'tvd_get_parkingpro', 'permission_callback' => '__return_true'],
        ['methods' => 'POST', 'callback' => 'tvd_save_parkingpro', 'permission_callback' => 'tvd_auth'],
    ]);

    register_rest_route('tvd-admin/v1', '/logo', [
        ['methods' => 'GET', 'callback' => 'tvd_get_logo', 'permission_callback' => '__return_true'],
        ['methods' => 'POST', 'callback' => 'tvd_save_logo', 'permission_callback' => 'tvd_auth'],
    ]);

    register_rest_route('tvd-admin/v1', '/booking-email', [
        ['methods' => 'GET', 'callback' => 'tvd_get_booking_email_settings', 'permission_callback' => 'tvd_auth'],
        ['methods' => 'POST', 'callback' => 'tvd_save_booking_email_settings', 'permission_callback' => 'tvd_auth'],
    ]);
});

function tvd_auth() {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!$h && function_exists('getallheaders')) {
        $hdrs = getallheaders();
        $h = $hdrs['Authorization'] ?? $hdrs['authorization'] ?? '';
    }
    if (!str_starts_with($h, 'Basic ')) return false;
    $decoded = base64_decode(substr($h, 6));
    [$u, $p] = explode(':', $decoded, 2) + ['', ''];
    return $u === get_option('tvd_wp_user') && $p === get_option('tvd_wp_pass');
}

function tvd_get_sections() {
    $def = [
        ['id'=>'home','label'=>'القسم الرئيسي','visible'=>true,'order'=>0],
        ['id'=>'tvd-stats','label'=>'الإحصائيات (24/7 · 5★ · 2min · 100%)','visible'=>true,'order'=>1],
        ['id'=>'buchen','label'=>'الحجز','visible'=>true,'order'=>2],
        ['id'=>'services','label'=>'الخدمات','visible'=>true,'order'=>3],
        ['id'=>'ablauf','label'=>'كيف يعمل','visible'=>true,'order'=>4],
        ['id'=>'parkingpro','label'=>'احجز الآن - ParkingPro','visible'=>true,'order'=>5],
        ['id'=>'ueber-uns','label'=>'من نحن','visible'=>true,'order'=>6],
        ['id'=>'kontakt','label'=>'تواصل معنا','visible'=>true,'order'=>7],
    ];
    $saved = get_option('tvd_sections', null);
    return new WP_REST_Response(['sections' => $saved !== null ? json_decode($saved, true) : $def]);
}

function tvd_save_sections(WP_REST_Request $req) {
    $sections = $req->get_param('sections');
    update_option('tvd_sections', json_encode($sections));
    return new WP_REST_Response(['ok' => true]);
}

function tvd_get_parkingpro() {
    return new WP_REST_Response(['embed' => get_option('tvd_parkingpro_embed', '')]);
}
function tvd_save_parkingpro(WP_REST_Request $req) {
    update_option('tvd_parkingpro_embed', $req->get_param('embed'));
    return new WP_REST_Response(['ok' => true]);
}

function tvd_get_logo() {
    return new WP_REST_Response([
        'type' => get_option('tvd_logo_type', 'svg'),
        'url'  => get_option('tvd_logo_url', ''),
    ]);
}
function tvd_save_logo(WP_REST_Request $req) {
    update_option('tvd_logo_type', $req->get_param('type'));
    update_option('tvd_logo_url', $req->get_param('url'));
    return new WP_REST_Response(['ok' => true]);
}

/* ──────────────────────────────────────────────
   Booking Email Settings REST
────────────────────────────────────────────── */
function tvd_get_booking_email_settings() {
    return new WP_REST_Response([
        'enabled'  => (bool) get_option('tvd_booking_email_enabled', true),
        'subject'  => get_option('tvd_booking_email_subject', 'Buchungsbestätigung – Travel Valet Düsseldorf'),
        'reply_to' => get_option('tvd_booking_email_reply', get_option('admin_email')),
    ]);
}
function tvd_save_booking_email_settings(WP_REST_Request $req) {
    update_option('tvd_booking_email_enabled', (bool) $req->get_param('enabled'));
    if ($req->get_param('subject')) update_option('tvd_booking_email_subject', sanitize_text_field($req->get_param('subject')));
    if ($req->get_param('reply_to')) update_option('tvd_booking_email_reply', sanitize_email($req->get_param('reply_to')));
    return new WP_REST_Response(['ok' => true]);
}

/* ──────────────────────────────────────────────
   Customer Confirmation Email
   — intercepts admin booking email via wp_mail
────────────────────────────────────────────── */
add_filter('wp_mail', function ($args) {
    if (!get_option('tvd_booking_email_enabled', true)) return $args;
    if ((($_POST['action'] ?? '') !== 'tvd_pl_submit_booking')) return $args;

    $email = sanitize_email($_POST['email'] ?? '');
    if (!$email) return $args;

    $vorname     = sanitize_text_field($_POST['vorname'] ?? '');
    $nachname    = sanitize_text_field($_POST['nachname'] ?? '');
    $anreise     = sanitize_text_field($_POST['anreise_datum'] ?? '');
    $ankunft     = sanitize_text_field($_POST['ankunftszeit'] ?? '');
    $abreise     = sanitize_text_field($_POST['abreise_datum'] ?? '');
    $lande       = sanitize_text_field($_POST['landezeit'] ?? '');
    $parkart     = sanitize_text_field($_POST['parkart'] ?? '');
    $kfz         = sanitize_text_field($_POST['kennzeichen'] ?? '');
    $modell      = sanitize_text_field($_POST['marke_modell'] ?? '');
    $reinigung   = sanitize_text_field($_POST['reinigung'] ?? 'keine');
    $days        = (int) ($_POST['days'] ?? 0);
    $price       = number_format((float)($_POST['price'] ?? 0), 2, ',', '.');
    $zahlung     = sanitize_text_field($_POST['zahlungsart'] ?? '');
    $ref         = strtoupper(substr(md5($email . $anreise . time()), 0, 8));

    $parkart_label = ($parkart === 'freiflaeche') ? 'Freiflächenpark' : 'Parkhaus (überdacht)';
    $zahlung_label = ($zahlung === 'online') ? 'Online (Zahlungslink per E-Mail)' : 'Bar bei Fahrzeugübergabe';

    $rein_labels = [];
    if (strpos($reinigung, 'aussen') !== false) $rein_labels[] = 'Außenreinigung';
    if (strpos($reinigung, 'innen') !== false) $rein_labels[] = 'Innenreinigung';
    $rein_text = $rein_labels ? implode(' + ', $rein_labels) : 'Keine';

    $subject   = get_option('tvd_booking_email_subject', 'Buchungsbestätigung – Travel Valet Düsseldorf');
    $reply_to  = get_option('tvd_booking_email_reply', get_option('admin_email'));
    $full_name = trim("$vorname $nachname") ?: 'Kunde';

    $html = <<<HTML
<!DOCTYPE html>
<html lang="de">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f4f6f9;font-family:Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f6f9;padding:32px 16px;">
  <tr><td align="center">
    <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,.08);">

      <!-- Header -->
      <tr><td style="background:linear-gradient(135deg,#0b0f1a,#13192b);padding:32px 40px;text-align:center;">
        <div style="font-size:28px;margin-bottom:8px;">✈️</div>
        <div style="color:#c9a84c;font-size:22px;font-weight:700;letter-spacing:1px;">Travel Valet Düsseldorf</div>
        <div style="color:#8b9bb4;font-size:13px;margin-top:4px;">Valet Parken · Flughafen DUS</div>
      </td></tr>

      <!-- Success Banner -->
      <tr><td style="background:#c9a84c;padding:16px 40px;text-align:center;">
        <div style="color:#0b0f1a;font-size:18px;font-weight:700;">✓ Buchung bestätigt!</div>
        <div style="color:#0b0f1a;font-size:13px;margin-top:4px;opacity:.8;">Referenznummer: <strong>TVD-{$ref}</strong></div>
      </td></tr>

      <!-- Greeting -->
      <tr><td style="padding:32px 40px 16px;">
        <p style="margin:0;color:#1a2035;font-size:16px;">Guten Tag, <strong>{$full_name}</strong>,</p>
        <p style="margin:12px 0 0;color:#4b5675;font-size:14px;line-height:1.6;">
          vielen Dank für Ihre Buchung! Wir haben Ihre Anfrage erhalten und bestätigen hiermit Ihre Reservierung.
          Unser Fahrer wird zum vereinbarten Zeitpunkt am Terminal des Flughafen Düsseldorf auf Sie warten.
        </p>
      </td></tr>

      <!-- Booking Details -->
      <tr><td style="padding:8px 40px 32px;">
        <div style="background:#f8f9fc;border-radius:12px;padding:24px;border:1px solid #e8ecf4;">
          <div style="font-size:13px;font-weight:700;color:#8b9bb4;text-transform:uppercase;letter-spacing:.08em;margin-bottom:16px;">Ihre Buchungsdetails</div>
          <table width="100%" cellpadding="0" cellspacing="0">
HTML;

    $rows = [
        ['📅 Anreise',    "$anreise um $ankunft Uhr"],
        ['🛬 Abreise',    "$abreise um $lande Uhr"],
        ['🕐 Dauer',      "$days Tag" . ($days !== 1 ? 'e' : '')],
        ['🚗 Parkart',    $parkart_label],
        ['🔑 Kennzeichen', $kfz],
        ['🚙 Fahrzeug',   $modell],
        ['🧹 Reinigung',  $rein_text],
        ['💳 Zahlung',    $zahlung_label],
        ['💰 Gesamtpreis', "€$price"],
    ];

    foreach ($rows as $i => [$label, $value]) {
        $bg = $i % 2 === 0 ? '#fff' : '#f8f9fc';
        $html .= <<<ROW
            <tr style="background:{$bg};">
              <td style="padding:10px 12px;color:#6b7a99;font-size:13px;border-radius:6px 0 0 6px;">{$label}</td>
              <td style="padding:10px 12px;color:#1a2035;font-size:13px;font-weight:600;text-align:right;">{$value}</td>
            </tr>
ROW;
    }

    $html .= <<<HTML
          </table>
        </div>
      </td></tr>

      <!-- Info box -->
      <tr><td style="padding:0 40px 32px;">
        <div style="background:#fffbf0;border:1px solid #f0d080;border-radius:12px;padding:20px;font-size:13px;color:#7a6020;line-height:1.6;">
          <strong>📍 Treffpunkt:</strong> Terminal des Flughafen Düsseldorf (DUS)<br>
          Unser Fahrer hält ein Schild mit Ihrem Namen. Bitte haben Sie Ihr Kennzeichen (<strong>{$kfz}</strong>) bereit.<br><br>
          <strong>📞 Bei Fragen:</strong> <a href="mailto:info.travelpark24@gmail.com" style="color:#c9a84c;">info.travelpark24@gmail.com</a>
        </div>
      </td></tr>

      <!-- Footer -->
      <tr><td style="background:#f8f9fc;padding:24px 40px;text-align:center;border-top:1px solid #e8ecf4;">
        <div style="font-size:12px;color:#8b9bb4;line-height:1.8;">
          Travel Valet Düsseldorf · Flughafen DUS<br>
          <a href="mailto:info.travelpark24@gmail.com" style="color:#c9a84c;text-decoration:none;">info.travelpark24@gmail.com</a>
        </div>
      </td></tr>

    </table>
  </td></tr>
</table>
</body></html>
HTML;

    $mail_headers = [
        'Content-Type: text/html; charset=UTF-8',
        "Reply-To: $reply_to",
        'From: Travel Valet Düsseldorf <' . get_option('admin_email') . '>',
    ];

    wp_mail($email, $subject, $html, $mail_headers);

    return $args;
}, 5);

/* ──────────────────────────────────────────────
   Frontend injection
────────────────────────────────────────────── */
add_action('wp_footer', 'tvd_inject_frontend', 99);

function tvd_inject_frontend() {
    $sections_raw = get_option('tvd_sections', null);
    $sections     = $sections_raw ? json_decode($sections_raw, true) : [];
    usort($sections, fn($a, $b) => ($a['order'] ?? 0) <=> ($b['order'] ?? 0));

    $logo_type = get_option('tvd_logo_type', 'svg');
    $logo_url  = get_option('tvd_logo_url', '');
    $pp_embed  = get_option('tvd_parkingpro_embed', '');

    $sections_json = json_encode($sections);
    $logo_type_js  = json_encode($logo_type);
    $logo_url_js   = json_encode($logo_url);
    $pp_embed_js   = json_encode($pp_embed);

    echo <<<JS
<script>
(function(){
  /* ── Sections order & visibility ── */
  var sections = {$sections_json};
  if (sections && sections.length) {
    var container = document.querySelector('.tvd-container') ? document.querySelector('body') : null;
    var allSections = Array.from(document.querySelectorAll('section[id], div[id]')).filter(function(el){
      return sections.some(function(s){ return s.id === el.id; });
    });
    sections.forEach(function(s) {
      var el = document.getElementById(s.id);
      if (!el) return;
      el.style.display = s.visible ? '' : 'none';
    });
    var ordered = sections
      .filter(function(s){ return s.visible; })
      .map(function(s){ return document.getElementById(s.id); })
      .filter(Boolean);
    if (ordered.length > 1) {
      var parent = ordered[0].parentNode;
      if (parent) {
        ordered.forEach(function(el){ parent.appendChild(el); });
      }
    }
  }

  /* ── Logo injection ── */
  var logoType = {$logo_type_js};
  var logoUrl  = {$logo_url_js};
  var brand = document.querySelector('.navbar-brand, .tvd-logo, [class*="brand"]');
  if (brand) {
    var span = document.createElement('span');
    span.className = 'tvd-injected-logo';
    span.style.cssText = 'display:inline-flex;align-items:center;margin-left:8px;vertical-align:middle;';
    if (logoType === 'url' && logoUrl) {
      var img = document.createElement('img');
      img.src = logoUrl;
      img.style.cssText = 'height:36px;width:auto;object-fit:contain;';
      img.alt = 'Logo';
      span.appendChild(img);
    } else {
      span.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.8 19.2L16 11l3.5-3.5C21 6 21 4 19.5 2.5c-1.5-1.5-3.5-1.5-5 0L11 6 2.8 4.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 6.2 7.3c.4.4.9.5 1.3.3l.5-.3c.4-.2.6-.7.5-1.1z"/></svg>';
    }
    brand.insertBefore(span, brand.firstChild);
  }

  /* ── ParkingPro section ── */
  var ppEmbed = {$pp_embed_js};
  var ppSec = document.getElementById('parkingpro');
  if (!ppSec) {
    ppSec = document.createElement('section');
    ppSec.id = 'parkingpro';
    ppSec.className = 'tvd-section tvd-bg-light';
    document.body.appendChild(ppSec);
  }
  if (ppEmbed) {
    ppSec.innerHTML = '<div class="tvd-container" style="padding:60px 20px;text-align:center;">' + ppEmbed + '</div>';
  }
})();
</script>
JS;
}
