<?php
/**
 * Plugin Name: TVD Admin Bridge
 * Description: Connects the TVD Admin Panel to this WordPress site.
 * Version: 1.5.0
 * Author: Travel Valet Düsseldorf
 */

if (!defined('ABSPATH')) exit;

function tvd_default_sections() {
    return [
        ['id' => 'home',       'label' => 'القسم الرئيسي',                        'visible' => true, 'order' => 0],
        ['id' => 'tvd-stats',  'label' => 'الإحصائيات (24/7 · 5★ · 2min · 100%)', 'visible' => true, 'order' => 1],
        ['id' => 'services',   'label' => 'الخدمات',                               'visible' => true, 'order' => 2],
        ['id' => 'ablauf',     'label' => 'كيف يعمل',                              'visible' => true, 'order' => 3],
        ['id' => 'buchen',     'label' => 'الحجز',                                 'visible' => true, 'order' => 4],
        ['id' => 'parkingpro', 'label' => 'احجز الآن - ParkingPro',               'visible' => true, 'order' => 5],
        ['id' => 'ueber-uns',  'label' => 'من نحن',                                'visible' => true, 'order' => 6],
        ['id' => 'kontakt',    'label' => 'تواصل معنا',                            'visible' => true, 'order' => 7],
    ];
}

add_action('rest_api_init', function () {
    register_rest_route('tvd-admin/v1', '/sections', [
        ['methods' => 'GET',  'callback' => 'tvd_get_sections',  'permission_callback' => 'tvd_auth'],
        ['methods' => 'POST', 'callback' => 'tvd_save_sections', 'permission_callback' => 'tvd_auth'],
    ]);
    register_rest_route('tvd-admin/v1', '/parkingpro', [
        ['methods' => 'GET',  'callback' => 'tvd_get_parkingpro',  'permission_callback' => 'tvd_auth'],
        ['methods' => 'POST', 'callback' => 'tvd_save_parkingpro', 'permission_callback' => 'tvd_auth'],
    ]);
    register_rest_route('tvd-admin/v1', '/logo', [
        ['methods' => 'GET',  'callback' => 'tvd_get_logo',  'permission_callback' => 'tvd_auth'],
        ['methods' => 'POST', 'callback' => 'tvd_save_logo', 'permission_callback' => 'tvd_auth'],
    ]);
});

function tvd_auth() { return current_user_can('manage_options'); }

function tvd_get_sections() {
    $saved = get_option('tvd_sections', null);
    if ($saved === null) {
        $sections = tvd_default_sections();
        update_option('tvd_sections', $sections);
    } else {
        $sections = $saved;
        $ids = array_column($sections, 'id');
        if (!in_array('parkingpro', $ids)) {
            $sections[] = ['id' => 'parkingpro', 'label' => 'احجز الآن - ParkingPro', 'visible' => true, 'order' => count($sections)];
            update_option('tvd_sections', $sections);
        }
    }
    return rest_ensure_response(['sections' => $sections]);
}

function tvd_save_sections(WP_REST_Request $req) {
    $body = $req->get_json_params();
    if (!isset($body['sections']) || !is_array($body['sections']))
        return new WP_Error('bad_request', 'sections array required', ['status' => 400]);
    update_option('tvd_sections', $body['sections']);
    return rest_ensure_response(['success' => true, 'sections' => $body['sections']]);
}

function tvd_get_parkingpro() {
    return rest_ensure_response(['embed' => get_option('tvd_parkingpro_embed', '')]);
}
function tvd_save_parkingpro(WP_REST_Request $req) {
    $body = $req->get_json_params();
    update_option('tvd_parkingpro_embed', isset($body['embed']) ? sanitize_textarea_field($body['embed']) : '');
    return rest_ensure_response(['success' => true]);
}

function tvd_get_logo() {
    return rest_ensure_response(['url' => get_option('tvd_logo_url', '')]);
}
function tvd_save_logo(WP_REST_Request $req) {
    $body = $req->get_json_params();
    update_option('tvd_logo_url', isset($body['url']) ? esc_url_raw($body['url']) : '');
    return rest_ensure_response(['success' => true]);
}

add_action('wp_footer', function () {
    $sections = get_option('tvd_sections', tvd_default_sections());
    $embed    = get_option('tvd_parkingpro_embed', '');
    $logoUrl  = get_option('tvd_logo_url', '');
    ?>
<script>
(function(){
  var sections     = <?php echo wp_json_encode($sections); ?>;
  var parkingEmbed = <?php echo wp_json_encode($embed); ?>;
  var logoUrl      = <?php echo wp_json_encode($logoUrl); ?>;

  var defaultSvg = '<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;vertical-align:middle;flex-shrink:0"><path d="M17.8 19.2 16 11l3.5-3.5C21 6 21 4 19 4c-2 0-4 1-4.5 2.5l-3.5 3.5-8.2-1.8c-.5-.1-.9.2-1 .7l-.3 1.3c-.2.8.2 1.6.9 2l6.4 3.2-1.7 2.6c-.3.5-.2 1.1.2 1.5l1 1c.4.4 1 .5 1.5.2l2.6-1.7 3.2 6.4c.4.8 1.2 1.1 2 .9l1.3-.3c.5-.1.8-.5.7-1z"/></svg>';

  function findEl(id) {
    if (id === 'tvd-stats') return document.querySelector('.tvd-stats');
    return document.getElementById(id);
  }

  function injectLogo() {
    var logoLinks = document.querySelectorAll('a.tvd-logo');
    logoLinks.forEach(function(link) {
      if (link.querySelector('.tvd-injected-logo')) return;
      var wrap = document.createElement('span');
      wrap.className = 'tvd-injected-logo';
      wrap.style.cssText = 'display:inline-flex;align-items:center;margin-right:8px;';
      if (logoUrl) {
        var img = document.createElement('img');
        img.src = logoUrl;
        img.alt = 'Logo';
        img.style.cssText = 'width:28px;height:28px;object-fit:contain;';
        wrap.appendChild(img);
      } else {
        wrap.innerHTML = defaultSvg;
      }
      link.style.cssText += 'display:inline-flex;align-items:center;gap:0;';
      link.insertBefore(wrap, link.firstChild);
    });
  }

  function injectParkingPro() {
    if (document.getElementById('parkingpro')) return;
    var footer = document.getElementById('tvd-footer') || document.querySelector('footer');
    if (!footer) return;
    var sec = document.createElement('section');
    sec.id = 'parkingpro';
    sec.style.cssText = 'padding:60px 20px;background:#f9f9f9;text-align:center;direction:ltr;';
    sec.innerHTML = '<div style="max-width:900px;margin:0 auto;">'
      + '<h2 style="font-size:2rem;font-weight:700;margin-bottom:8px;color:#1a1a2e;">Jetzt Parkplatz buchen</h2>'
      + '<p style="color:#666;margin-bottom:32px;">Schnell und einfach mit ParkingPro</p>'
      + '<div id="parkingpro-widget">'
      + (parkingEmbed ? parkingEmbed
        : '<div style="border:2px dashed #ccc;border-radius:12px;padding:40px;color:#999;">'
          + '<p style="margin:0;">Buchungs-Widget erscheint hier</p></div>')
      + '</div></div>';
    footer.parentNode.insertBefore(sec, footer);
  }

  function applySections() {
    injectParkingPro();
    injectLogo();
    var footer = document.getElementById('tvd-footer') || document.querySelector('footer');
    if (!footer) return;
    var sorted = sections.slice().sort(function(a,b){ return a.order - b.order; });
    sorted.forEach(function(s) {
      var el = findEl(s.id);
      if (!el) return;
      el.style.display = s.visible ? '' : 'none';
      if (s.visible) footer.parentNode.insertBefore(el, footer);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applySections);
  } else {
    applySections();
  }
})();
</script>
    <?php
});
