<?php
/**
 * Plugin Name: TVD Admin Bridge
 * Description: Bridge between TVD Admin Panel and WordPress
 * Version: 1.8.0
 * Author: Travel Valet Dusseldorf
 */

if (!defined('ABSPATH')) exit;

/* ─── REST API ─────────────────────────────────────────────────────────────── */
add_action('rest_api_init', function () {
    register_rest_route('tvd-admin/v1', '/sections', array(
        array('methods'=>'GET',  'callback'=>'tvd_get_sections',    'permission_callback'=>'__return_true'),
        array('methods'=>'POST', 'callback'=>'tvd_save_sections',   'permission_callback'=>'tvd_is_admin'),
    ));
    register_rest_route('tvd-admin/v1', '/parkingpro', array(
        array('methods'=>'GET',  'callback'=>'tvd_get_parkingpro',  'permission_callback'=>'__return_true'),
        array('methods'=>'POST', 'callback'=>'tvd_save_parkingpro', 'permission_callback'=>'tvd_is_admin'),
    ));
    register_rest_route('tvd-admin/v1', '/logo', array(
        array('methods'=>'GET',  'callback'=>'tvd_get_logo',        'permission_callback'=>'__return_true'),
        array('methods'=>'POST', 'callback'=>'tvd_save_logo',       'permission_callback'=>'tvd_is_admin'),
    ));
    register_rest_route('tvd-admin/v1', '/booking-email', array(
        array('methods'=>'GET',  'callback'=>'tvd_get_booking_email',  'permission_callback'=>'tvd_is_admin'),
        array('methods'=>'POST', 'callback'=>'tvd_save_booking_email', 'permission_callback'=>'tvd_is_admin'),
    ));
});

function tvd_is_admin() {
    return current_user_can('manage_options');
}

function tvd_get_sections() {
    $def = array(
        array('id'=>'home',      'label'=>'القسم الرئيسي','visible'=>true,'order'=>0),
        array('id'=>'tvd-stats', 'label'=>'الاحصائيات',  'visible'=>true,'order'=>1),
        array('id'=>'buchen',    'label'=>'الحجز',        'visible'=>true,'order'=>2),
        array('id'=>'services',  'label'=>'الخدمات',      'visible'=>true,'order'=>3),
        array('id'=>'ablauf',    'label'=>'كيف يعمل',     'visible'=>true,'order'=>4),
        array('id'=>'parkingpro','label'=>'ParkingPro',   'visible'=>true,'order'=>5),
        array('id'=>'ueber-uns', 'label'=>'من نحن',       'visible'=>true,'order'=>6),
        array('id'=>'kontakt',   'label'=>'تواصل معنا',   'visible'=>true,'order'=>7),
    );
    $saved = get_option('tvd_sections', null);
    return new WP_REST_Response(array(
        'sections' => ($saved !== null) ? json_decode($saved, true) : $def,
        'saved'    => ($saved !== null),
    ));
}

function tvd_save_sections($req) {
    update_option('tvd_sections', json_encode($req->get_param('sections')));
    return new WP_REST_Response(array('ok'=>true));
}

function tvd_get_parkingpro() {
    return new WP_REST_Response(array('embed'=>get_option('tvd_parkingpro_embed','')));
}

function tvd_save_parkingpro($req) {
    update_option('tvd_parkingpro_embed', $req->get_param('embed'));
    return new WP_REST_Response(array('ok'=>true));
}

function tvd_get_logo() {
    return new WP_REST_Response(array(
        'type' => get_option('tvd_logo_type','svg'),
        'url'  => get_option('tvd_logo_url',''),
    ));
}

function tvd_save_logo($req) {
    update_option('tvd_logo_type', $req->get_param('type'));
    update_option('tvd_logo_url',  $req->get_param('url'));
    return new WP_REST_Response(array('ok'=>true));
}

function tvd_get_booking_email() {
    return new WP_REST_Response(array(
        'enabled'  => (bool) get_option('tvd_booking_email_enabled', 1),
        'subject'  => get_option('tvd_booking_email_subject', 'Buchungsbestatigung - Travel Valet Dusseldorf'),
        'reply_to' => get_option('tvd_booking_email_reply', get_option('admin_email')),
    ));
}

function tvd_save_booking_email($req) {
    $en = $req->get_param('enabled');
    update_option('tvd_booking_email_enabled', $en ? 1 : 0);
    $s = $req->get_param('subject');
    if ($s) {
        update_option('tvd_booking_email_subject', sanitize_text_field($s));
    }
    $r = $req->get_param('reply_to');
    if ($r) {
        update_option('tvd_booking_email_reply', sanitize_email($r));
    }
    return new WP_REST_Response(array('ok'=>true));
}

/* ─── Booking confirmation email ───────────────────────────────────────────── */
/*
 * Hook at priority 1 (before TVD Buchungssystem at default priority 10).
 * Captures POST data and registers a shutdown function.
 * The shutdown function runs AFTER wp_send_json_success() + die(),
 * so the booking response reaches the browser first, then email is sent.
 */
add_action('wp_ajax_nopriv_tvd_pl_submit_booking', 'tvd_capture_booking_data', 1);

function tvd_capture_booking_data() {
    if (!get_option('tvd_booking_email_enabled', 1)) {
        return;
    }
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    if (!$email || !is_email($email)) {
        return;
    }
    $GLOBALS['tvd_booking_post'] = $_POST;
    register_shutdown_function('tvd_send_booking_email');
}

function tvd_send_booking_email() {
    if (empty($GLOBALS['tvd_booking_post'])) {
        return;
    }
    $p = $GLOBALS['tvd_booking_post'];

    $email    = sanitize_email($p['email']);
    $vorname  = sanitize_text_field(isset($p['vorname'])   ? $p['vorname']   : '');
    $nachname = sanitize_text_field(isset($p['nachname'])  ? $p['nachname']  : '');
    $anreise  = sanitize_text_field(isset($p['anreise'])   ? $p['anreise']   : '');
    $ankunft  = sanitize_text_field(isset($p['ankunft'])   ? $p['ankunft']   : '');
    $abreise  = sanitize_text_field(isset($p['abreise'])   ? $p['abreise']   : '');
    $lande    = sanitize_text_field(isset($p['lande'])     ? $p['lande']     : '');
    $parkart  = sanitize_text_field(isset($p['parkart'])   ? $p['parkart']   : '');
    $kfz      = sanitize_text_field(isset($p['kfz'])       ? $p['kfz']       : '');
    $modell   = sanitize_text_field(isset($p['modell'])    ? $p['modell']    : '');
    $days     = (int)(isset($p['days'])  ? $p['days']  : 0);
    $price    = number_format((float)(isset($p['price']) ? $p['price'] : 0), 2, ',', '.');
    $zahlung  = sanitize_text_field(isset($p['zahlung'])   ? $p['zahlung']   : '');

    $name = trim($vorname . ' ' . $nachname);
    if (!$name) {
        $name = 'Kunde';
    }
    $ref   = 'TVD-' . strtoupper(substr(md5($email . $anreise . time()), 0, 8));
    $pl    = ($parkart === 'freiflaeche') ? 'Freiflaechenpark' : 'Parkhaus (ueberdacht)';
    $zl    = ($zahlung === 'online') ? 'Online (Zahlungslink per E-Mail)' : 'Bar bei Uebergabe';
    $dt    = $days . ($days !== 1 ? ' Tage' : ' Tag');

    $rows = array(
        array('Anreise',    $anreise . ' um ' . $ankunft . ' Uhr'),
        array('Abreise',    $abreise . ' um ' . $lande   . ' Uhr'),
        array('Dauer',      $dt),
        array('Parkart',    $pl),
        array('Kennzeichen',$kfz),
        array('Fahrzeug',   $modell),
        array('Zahlung',    $zl),
        array('Preis',      'EUR ' . $price),
    );

    $tbody = '';
    $i = 0;
    foreach ($rows as $row) {
        $bg = ($i % 2 === 0) ? '#ffffff' : '#f8f9fc';
        $tbody .= '<tr style="background:' . $bg . ';">'
            . '<td style="padding:10px 14px;color:#6b7a99;font-size:13px;">' . esc_html($row[0]) . '</td>'
            . '<td style="padding:10px 14px;color:#1a2035;font-size:13px;font-weight:600;text-align:right;">' . esc_html($row[1]) . '</td>'
            . '</tr>';
        $i++;
    }

    $html = '<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8"></head>'
        . '<body style="margin:0;padding:0;background:#f4f6f9;font-family:Arial,sans-serif;">'
        . '<table width="100%" cellpadding="0" cellspacing="0" style="padding:32px 16px;"><tr><td align="center">'
        . '<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#fff;border-radius:16px;overflow:hidden;">'
        . '<tr><td style="background:#0b0f1a;padding:32px 40px;text-align:center;">'
        . '<div style="color:#c9a84c;font-size:22px;font-weight:700;">Travel Valet Dusseldorf</div>'
        . '<div style="color:#8b9bb4;font-size:13px;margin-top:4px;">Valet Parken am Flughafen DUS</div>'
        . '</td></tr>'
        . '<tr><td style="background:#c9a84c;padding:14px 40px;text-align:center;">'
        . '<div style="color:#0b0f1a;font-size:17px;font-weight:700;">Buchung bestatigt</div>'
        . '<div style="color:#0b0f1a;font-size:12px;margin-top:2px;">' . esc_html($ref) . '</div>'
        . '</td></tr>'
        . '<tr><td style="padding:28px 40px 12px;">'
        . '<p style="margin:0;color:#1a2035;font-size:15px;">Guten Tag, <strong>' . esc_html($name) . '</strong>,</p>'
        . '<p style="margin:10px 0 0;color:#4b5675;font-size:14px;line-height:1.6;">vielen Dank fuer Ihre Buchung! Unser Fahrer wird zum vereinbarten Zeitpunkt am Terminal auf Sie warten.</p>'
        . '</td></tr>'
        . '<tr><td style="padding:8px 40px 28px;">'
        . '<div style="border:1px solid #e8ecf4;border-radius:10px;overflow:hidden;">'
        . '<table width="100%" cellpadding="0" cellspacing="0">' . $tbody . '</table>'
        . '</div></td></tr>'
        . '<tr><td style="padding:0 40px 28px;">'
        . '<div style="background:#fffbf0;border:1px solid #f0d080;border-radius:10px;padding:18px;font-size:13px;color:#7a6020;line-height:1.6;">'
        . '<strong>Treffpunkt:</strong> Terminal Flughafen Dusseldorf (DUS)<br><br>'
        . '<strong>Fragen?</strong> info.travelpark24@gmail.com'
        . '</div></td></tr>'
        . '<tr><td style="background:#f8f9fc;padding:20px 40px;text-align:center;border-top:1px solid #e8ecf4;">'
        . '<div style="font-size:12px;color:#8b9bb4;">Travel Valet Dusseldorf &middot; info.travelpark24@gmail.com</div>'
        . '</td></tr>'
        . '</table></td></tr></table>'
        . '</body></html>';

    $subject = get_option('tvd_booking_email_subject', 'Buchungsbestatigung - Travel Valet Dusseldorf');
    $reply   = get_option('tvd_booking_email_reply', get_option('admin_email'));
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'Reply-To: ' . $reply,
    );
    wp_mail($email, $subject, $html, $headers);
}

/* ─── Frontend JS (only applies saved settings) ────────────────────────────── */
add_action('wp_footer', 'tvd_inject_frontend', 99);

function tvd_inject_frontend() {
    $sections_raw = get_option('tvd_sections', null);
    $sections_js  = ($sections_raw !== null) ? $sections_raw : '[]';
    $logo_url     = get_option('tvd_logo_url', '');
    $logo_type    = get_option('tvd_logo_type', '');
    $pp_embed     = get_option('tvd_parkingpro_embed', '');

    $sj = $sections_js;
    $lu = json_encode($logo_url);
    $lt = json_encode($logo_type);
    $pp = json_encode($pp_embed);

    echo '<script>' . "\n";
    echo '(function(){' . "\n";

    /* Sections visibility & order — only if explicitly saved */
    echo 'var S=' . $sj . ';';
    echo 'if(S&&S.length){';
    echo 'S.forEach(function(s){var e=document.getElementById(s.id);if(e)e.style.display=s.visible?"":"none";});';
    echo 'var vis=S.filter(function(s){return s.visible;});';
    echo 'vis.sort(function(a,b){return(a.order||0)-(b.order||0);});';
    echo 'var els=vis.map(function(s){return document.getElementById(s.id);}).filter(Boolean);';
    echo 'if(els.length>1){var par=els[0].parentNode;if(par){els.forEach(function(el){par.appendChild(el);});}}';
    echo '}' . "\n";

    /* Logo — only if URL type and URL is saved */
    echo 'var lt=' . $lt . ',lu=' . $lu . ';';
    echo 'if(lt==="url"&&lu){';
    echo 'var br=document.querySelector(".navbar-brand,.tvd-logo,[class*=\'brand\']");';
    echo 'if(br&&!br.querySelector(".tvd-li")){';
    echo 'var im=document.createElement("img");im.src=lu;im.style.cssText="height:36px;width:auto;vertical-align:middle;margin-left:8px;";im.className="tvd-li";';
    echo 'br.insertBefore(im,br.firstChild);}}' . "\n";

    /* ParkingPro — only if embed code is saved */
    echo 'var pp=' . $pp . ';';
    echo 'if(pp){var ps=document.getElementById("parkingpro");';
    echo 'if(!ps){ps=document.createElement("section");ps.id="parkingpro";document.body.appendChild(ps);}';
    echo 'ps.innerHTML=\'<div style="padding:60px 20px;text-align:center;">\'+pp+\'</div>\';}' . "\n";

    echo '})();' . "\n";
    echo '</script>' . "\n";
}
