<?php
/*
Plugin Name: TVD Admin Bridge
Description: REST API bridge - controls section visibility and order on traveldüsseldorf.de
Version: 1.3.0
Author: Travel Valet Admin Panel
*/

if (!defined('ABSPATH')) exit;

function tvd_default_sections() {
    return [
        ['id' => 'home',      'label' => 'القسم الرئيسي',                    'visible' => true, 'order' => 0],
        ['id' => 'tvd-stats', 'label' => 'الإحصائيات (24/7 · 5★ · 2min · 100%)', 'visible' => true, 'order' => 1],
        ['id' => 'services',  'label' => 'الخدمات',                           'visible' => true, 'order' => 2],
        ['id' => 'ablauf',    'label' => 'كيف يعمل',                          'visible' => true, 'order' => 3],
        ['id' => 'buchen',    'label' => 'الحجز',                             'visible' => true, 'order' => 4],
        ['id' => 'ueber-uns', 'label' => 'من نحن',                            'visible' => true, 'order' => 5],
        ['id' => 'kontakt',   'label' => 'التواصل',                           'visible' => true, 'order' => 6],
    ];
}

add_action('rest_api_init', function () {

    register_rest_route('tvd-admin/v1', '/sections', [
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function () {
            $saved    = get_option('tvd_sections_config', null);
            $sections = is_array($saved) ? $saved : tvd_default_sections();
            return rest_ensure_response(['sections' => $sections]);
        },
    ]);

    register_rest_route('tvd-admin/v1', '/sections', [
        'methods'             => 'POST',
        'permission_callback' => function () { return current_user_can('manage_options'); },
        'callback'            => function (WP_REST_Request $req) {
            $body     = $req->get_json_params();
            $sections = isset($body['sections']) && is_array($body['sections']) ? $body['sections'] : null;
            if (!$sections) return new WP_Error('invalid_data', 'Expected { sections: [...] }', ['status' => 400]);
            update_option('tvd_sections_config', $sections);
            return rest_ensure_response(['sections' => $sections]);
        },
    ]);
});

add_action('wp_footer', function () {
    $config = get_option('tvd_sections_config', null);
    if (!is_array($config)) $config = tvd_default_sections();
    $json = wp_json_encode($config);
    ?>
<script id="tvd-admin-bridge">
(function () {
  try {
    var cfg = <?php echo $json; ?>;
    cfg.sort(function (a, b) { return (a.order || 0) - (b.order || 0); });

    // Find element by id first, then by class (handles <div class="tvd-stats">)
    function findEl(id) {
      return document.getElementById(id) || document.querySelector('.' + id);
    }

    var items = cfg.map(function (s) { return { el: findEl(s.id), cfg: s }; });

    // Apply visibility
    items.forEach(function (item) {
      if (item.el) item.el.style.display = item.cfg.visible ? '' : 'none';
    });

    // Insert all items before the footer, in sorted order
    var footer = document.getElementById('tvd-footer') || document.querySelector('footer') || null;
    var ref    = footer || null;

    items.forEach(function (item) {
      if (!item.el) return;
      var parent = ref ? ref.parentNode : document.body;
      parent.insertBefore(item.el, ref);
    });

  } catch (e) { console.warn('TVD Admin Bridge:', e); }
})();
</script>
    <?php
});
