<?php
/**
 * Plugin Name: TVD Admin Bridge
 * Description: Connects the TVD Admin Panel to this WordPress site.
 * Version: 1.4.0
 * Author: Travel Valet Düsseldorf
 */

if (!defined('ABSPATH')) exit;

// ── Default sections ─────────────────────────────────────────────────────────
function tvd_default_sections() {
    return [
        ['id' => 'home',        'label' => 'القسم الرئيسي',              'visible' => true, 'order' => 0],
        ['id' => 'tvd-stats',   'label' => 'الإحصائيات (24/7 · 5★ · 2min · 100%)', 'visible' => true, 'order' => 1],
        ['id' => 'services',    'label' => 'الخدمات',                   'visible' => true, 'order' => 2],
        ['id' => 'ablauf',      'label' => 'كيف يعمل',                  'visible' => true, 'order' => 3],
        ['id' => 'buchen',      'label' => 'الحجز',                     'visible' => true, 'order' => 4],
        ['id' => 'parkingpro',  'label' => 'احجز الآن - ParkingPro',    'visible' => true, 'order' => 5],
        ['id' => 'ueber-uns',   'label' => 'من نحن',                    'visible' => true, 'order' => 6],
        ['id' => 'kontakt',     'label' => 'تواصل معنا',                'visible' => true, 'order' => 7],
    ];
}

// ── REST API ──────────────────────────────────────────────────────────────────
add_action('rest_api_init', function () {

    // GET/POST sections
    register_rest_route('tvd-admin/v1', '/sections', [
        [
            'methods'             => 'GET',
            'callback'            => 'tvd_get_sections',
            'permission_callback' => 'tvd_auth',
        ],
        [
            'methods'             => 'POST',
            'callback'            => 'tvd_save_sections',
            'permission_callback' => 'tvd_auth',
        ],
    ]);

    // GET/POST parkingpro widget embed code
    register_rest_route('tvd-admin/v1', '/parkingpro', [
        [
            'methods'             => 'GET',
            'callback'            => 'tvd_get_parkingpro',
            'permission_callback' => 'tvd_auth',
        ],
        [
            'methods'             => 'POST',
            'callback'            => 'tvd_save_parkingpro',
            'permission_callback' => 'tvd_auth',
        ],
    ]);
});

function tvd_auth() {
    return current_user_can('manage_options');
}

function tvd_get_sections() {
    $saved = get_option('tvd_sections', null);
    if ($saved === null) {
        $sections = tvd_default_sections();
        update_option('tvd_sections', $sections);
    } else {
        $sections = $saved;
        // Add parkingpro if missing from old installs
        $ids = array_column($sections, 'id');
        if (!in_array('parkingpro', $ids)) {
            $sections[] = ['id' => 'parkingpro', 'label' => 'احجز الآن - ParkingPro', 'visible' => true, 'order' => count($sections)];
            update_option('tvd_sections', $sections);
        }
    }
    return rest_ensure_response(['sections' => $sections]);
}

function tvd_save_sections(WP_REST_Request $req) {
    $body = $req->get_json_params();
    if (!isset($body['sections']) || !is_array($body['sections'])) {
        return new WP_Error('bad_request', 'sections array required', ['status' => 400]);
    }
    update_option('tvd_sections', $body['sections']);
    return rest_ensure_response(['success' => true, 'sections' => $body['sections']]);
}

function tvd_get_parkingpro() {
    $embed = get_option('tvd_parkingpro_embed', '');
    return rest_ensure_response(['embed' => $embed]);
}

function tvd_save_parkingpro(WP_REST_Request $req) {
    $body  = $req->get_json_params();
    $embed = isset($body['embed']) ? sanitize_textarea_field($body['embed']) : '';
    update_option('tvd_parkingpro_embed', $embed);
    return rest_ensure_response(['success' => true, 'embed' => $embed]);
}

// ── Frontend JS injection ─────────────────────────────────────────────────────
add_action('wp_footer', function () {
    $sections = get_option('tvd_sections', tvd_default_sections());
    $embed    = get_option('tvd_parkingpro_embed', '');
    $json     = wp_json_encode($sections);
    $embedJs  = wp_json_encode($embed);
    ?>
<script>
(function(){
  var sections = <?php echo $json; ?>;
  var parkingEmbed = <?php echo $embedJs; ?>;

  // ── helper: find element by id or class ──────────────────────────────────
  function findEl(id) {
    if (id === 'tvd-stats') return document.querySelector('.tvd-stats');
    return document.getElementById(id);
  }

  // ── inject ParkingPro section if not already in DOM ──────────────────────
  function injectParkingPro() {
    if (document.getElementById('parkingpro')) return;
    var footer = document.getElementById('tvd-footer') || document.querySelector('footer');
    if (!footer) return;
    var sec = document.createElement('section');
    sec.id = 'parkingpro';
    sec.style.cssText = 'padding:60px 20px;background:#f9f9f9;text-align:center;direction:rtl;';
    sec.innerHTML = '<div style="max-width:900px;margin:0 auto;">'
      + '<h2 style="font-size:2rem;font-weight:700;margin-bottom:8px;color:#1a1a2e;">احجز موقفك الآن</h2>'
      + '<p style="color:#666;margin-bottom:32px;font-size:1rem;">احجز مكان انتظارك بسرعة وسهولة مع ParkingPro</p>'
      + '<div id="parkingpro-widget">'
      + (parkingEmbed
          ? parkingEmbed
          : '<div style="border:2px dashed #ccc;border-radius:12px;padding:40px;color:#999;">'
            + '<p style="font-size:1.1rem;margin:0;">ويدجت الحجز سيظهر هنا</p>'
            + '<p style="font-size:0.85rem;margin-top:8px;">أضف كود الويدجت من لوحة التحكم</p>'
            + '</div>')
      + '</div>'
      + '</div>';
    footer.parentNode.insertBefore(sec, footer);
  }

  // ── apply sections order + visibility ───────────────────────────────────
  function applySections() {
    injectParkingPro();
    var footer = document.getElementById('tvd-footer') || document.querySelector('footer');
    if (!footer) return;

    var sorted = sections.slice().sort(function(a,b){ return a.order - b.order; });

    sorted.forEach(function(s) {
      var el = findEl(s.id);
      if (!el) return;
      el.style.display = s.visible ? '' : 'none';
      if (s.visible) {
        footer.parentNode.insertBefore(el, footer);
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applySections);
  } else {
    applySections();
  }
})();
</script>
    <?php
});
