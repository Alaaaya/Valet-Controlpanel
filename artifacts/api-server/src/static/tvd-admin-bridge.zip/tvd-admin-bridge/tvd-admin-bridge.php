<?php
/*
Plugin Name: TVD Admin Bridge
Description: REST API bridge - controls section visibility and order on traveldüsseldorf.de
Version: 1.2.0
Author: Travel Valet Admin Panel
*/

if (!defined('ABSPATH')) exit;

// ── Default sections ─────────────────────────────────────────────────────────
function tvd_default_sections() {
    return [
        ['id' => 'home',      'label' => 'القسم الرئيسي',  'visible' => true, 'order' => 0],
        ['id' => 'services',  'label' => 'الخدمات',         'visible' => true, 'order' => 1],
        ['id' => 'ablauf',    'label' => 'كيف يعمل',        'visible' => true, 'order' => 2],
        ['id' => 'buchen',    'label' => 'الحجز',           'visible' => true, 'order' => 3],
        ['id' => 'ueber-uns', 'label' => 'من نحن',          'visible' => true, 'order' => 4],
        ['id' => 'kontakt',   'label' => 'التواصل',         'visible' => true, 'order' => 5],
    ];
}

// ── REST API ─────────────────────────────────────────────────────────────────
add_action('rest_api_init', function () {

    // GET /wp-json/tvd-admin/v1/sections  (public)
    register_rest_route('tvd-admin/v1', '/sections', [
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function () {
            $saved = get_option('tvd_sections_config', null);
            $sections = is_array($saved) ? $saved : tvd_default_sections();
            return rest_ensure_response(['sections' => $sections]);
        },
    ]);

    // POST /wp-json/tvd-admin/v1/sections  (authenticated)
    register_rest_route('tvd-admin/v1', '/sections', [
        'methods'             => 'POST',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
        'callback'            => function (WP_REST_Request $req) {
            $body     = $req->get_json_params();
            $sections = isset($body['sections']) && is_array($body['sections'])
                        ? $body['sections']
                        : null;
            if (!$sections) {
                return new WP_Error('invalid_data', 'Expected { sections: [...] }', ['status' => 400]);
            }
            update_option('tvd_sections_config', $sections);
            return rest_ensure_response(['sections' => $sections]);
        },
    ]);
});

// ── Inject JS into every page ────────────────────────────────────────────────
add_action('wp_footer', function () {
    $config = get_option('tvd_sections_config', null);
    if (!is_array($config)) $config = tvd_default_sections();

    $json = wp_json_encode($config);
    ?>
<script id="tvd-admin-bridge">
(function () {
  try {
    var cfg = <?php echo $json; ?>;

    // Sort by order
    cfg.sort(function (a, b) { return (a.order || 0) - (b.order || 0); });

    // Build element list
    var items = cfg.map(function (s) {
      return { el: document.getElementById(s.id), cfg: s };
    });

    // Apply visibility
    items.forEach(function (item) {
      if (!item.el) return;
      item.el.style.display = item.cfg.visible ? '' : 'none';
    });

    // Reorder: find the footer as reference node
    // All sections will be inserted BEFORE the footer (not appended to end of body)
    var firstEl = null;
    for (var i = 0; i < items.length; i++) {
      if (items[i].el) { firstEl = items[i].el; break; }
    }
    if (!firstEl) return;

    var parent = firstEl.parentNode;

    // Find the footer element (reference: insert sections before it)
    var footer = document.getElementById('tvd-footer')
              || parent.querySelector('footer')
              || null;

    // Insert each section before the footer, in sorted order
    items.forEach(function (item) {
      if (item.el) {
        parent.insertBefore(item.el, footer);
      }
    });

  } catch (e) {
    console.warn('TVD Admin Bridge:', e);
  }
})();
</script>
    <?php
});
