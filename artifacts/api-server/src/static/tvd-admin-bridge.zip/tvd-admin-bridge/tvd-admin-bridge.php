<?php
/**
 * Plugin Name: TVD Admin Bridge
 * Description: Bridge between TVD Admin Panel and WordPress
 * Version: 1.6.1
 * Author: Travel Valet Düsseldorf
 */

if (!defined('ABSPATH')) exit;

/* ──────────────────────────────────────────────
   REST API
────────────────────────────────────────────── */
add_action('rest_api_init', function () {
    register_rest_route('tvd-admin/v1', '/sections', array(
        array('methods' => 'GET',  'callback' => 'tvd_get_sections',  'permission_callback' => '__return_true'),
        array('methods' => 'POST', 'callback' => 'tvd_save_sections', 'permission_callback' => 'tvd_auth'),
    ));
    register_rest_route('tvd-admin/v1', '/parkingpro', array(
        array('methods' => 'GET',  'callback' => 'tvd_get_parkingpro',  'permission_callback' => '__return_true'),
        array('methods' => 'POST', 'callback' => 'tvd_save_parkingpro', 'permission_callback' => 'tvd_auth'),
    ));
    register_rest_route('tvd-admin/v1', '/logo', array(
        array('methods' => 'GET',  'callback' => 'tvd_get_logo',  'permission_callback' => '__return_true'),
        array('methods' => 'POST', 'callback' => 'tvd_save_logo', 'permission_callback' => 'tvd_auth'),
    ));
    register_rest_route('tvd-admin/v1', '/booking-email', array(
        array('methods' => 'GET',  'callback' => 'tvd_get_booking_email_settings',  'permission_callback' => 'tvd_auth'),
        array('methods' => 'POST', 'callback' => 'tvd_save_booking_email_settings', 'permission_callback' => 'tvd_auth'),
    ));
});

function tvd_auth() {
    $h = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
    if (!$h && function_exists('getallheaders')) {
        $hdrs = getallheaders();
        $h = isset($hdrs['Authorization']) ? $hdrs['Authorization'] : (isset($hdrs['authorization']) ? $hdrs['authorization'] : '');
    }
    if (substr($h, 0, 6) !== 'Basic ') return false;
    $decoded = base64_decode(substr($h, 6));
    $parts = explode(':', $decoded, 2);
    $u = isset($parts[0]) ? $parts[0] : '';
    $p = isset($parts[1]) ? $parts[1] : '';
    return $u === get_option('tvd_wp_user') && $p === get_option('tvd_wp_pass');
}

function tvd_get_sections() {
    $def = array(
        array('id'=>'home',       'label'=>'القسم الرئيسي',                     'visible'=>true,'order'=>0),
        array('id'=>'tvd-stats',  'label'=>'الإحصائيات (24/7 · 5★ · 2min · 100%)','visible'=>true,'order'=>1),
        array('id'=>'buchen',     'label'=>'الحجز',                              'visible'=>true,'order'=>2),
        array('id'=>'services',   'label'=>'الخدمات',                            'visible'=>true,'order'=>3),
        array('id'=>'ablauf',     'label'=>'كيف يعمل',                           'visible'=>true,'order'=>4),
        array('id'=>'parkingpro', 'label'=>'احجز الآن - ParkingPro',             'visible'=>true,'order'=>5),
        array('id'=>'ueber-uns',  'label'=>'من نحن',                             'visible'=>true,'order'=>6),
        array('id'=>'kontakt',    'label'=>'تواصل معنا',                         'visible'=>true,'order'=>7),
    );
    $saved = get_option('tvd_sections', null);
    return new WP_REST_Response(array('sections' => $saved !== null ? json_decode($saved, true) : $def));
}
function tvd_save_sections($req) {
    update_option('tvd_sections', json_encode($req->get_param('sections')));
    return new WP_REST_Response(array('ok' => true));
}
function tvd_get_parkingpro() {
    return new WP_REST_Response(array('embed' => get_option('tvd_parkingpro_embed', '')));
}
function tvd_save_parkingpro($req) {
    update_option('tvd_parkingpro_embed', $req->get_param('embed'));
    return new WP_REST_Response(array('ok' => true));
}
function tvd_get_logo() {
    return new WP_REST_Response(array(
        'type' => get_option('tvd_logo_type', 'svg'),
        'url'  => get_option('tvd_logo_url', ''),
    ));
}
function tvd_save_logo($req) {
    update_option('tvd_logo_type', $req->get_param('type'));
    update_option('tvd_logo_url',  $req->get_param('url'));
    return new WP_REST_Response(array('ok' => true));
}
function tvd_get_booking_email_settings() {
    return new WP_REST_Response(array(
        'enabled'  => (bool) get_option('tvd_booking_email_enabled', 1),
        'subject'  => get_option('tvd_booking_email_subject', 'Buchungsbestätigung – Travel Valet Düsseldorf'),
        'reply_to' => get_option('tvd_booking_email_reply', get_option('admin_email')),
    ));
}
function tvd_save_booking_email_settings($req) {
    update_option('tvd_booking_email_enabled', $req->get_param('enabled') ? 1 : 0);
    $s = $req->get_param('subject');
    $r = $req->get_param('reply_to');
    if ($s) update_option('tvd_booking_email_subject', sanitize_text_field($s));
    if ($r) update_option('tvd_booking_email_reply',   sanitize_email($r));
    return new WP_REST_Response(array('ok' => true));
}

/* ──────────────────────────────────────────────
   Customer Confirmation Email
────────────────────────────────────────────── */
add_filter('wp_mail', 'tvd_intercept_booking_mail', 5);
function tvd_intercept_booking_mail($args) {
    if (!get_option('tvd_booking_email_enabled', 1)) return $args;
    if (!isset($_POST['action']) || $_POST['action'] !== 'tvd_pl_submit_booking') return $args;

    $email = sanitize_email(isset($_POST['email']) ? $_POST['email'] : '');
    if (!$email) return $args;

    $vorname   = sanitize_text_field(isset($_POST['vorname'])      ? $_POST['vorname']      : '');
    $nachname  = sanitize_text_field(isset($_POST['nachname'])     ? $_POST['nachname']     : '');
    $anreise   = sanitize_text_field(isset($_POST['anreise_datum'])? $_POST['anreise_datum']: '');
    $ankunft   = sanitize_text_field(isset($_POST['ankunftszeit']) ? $_POST['ankunftszeit'] : '');
    $abreise   = sanitize_text_field(isset($_POST['abreise_datum'])? $_POST['abreise_datum']: '');
    $lande     = sanitize_text_field(isset($_POST['landezeit'])    ? $_POST['landezeit']    : '');
    $parkart   = sanitize_text_field(isset($_POST['parkart'])      ? $_POST['parkart']      : '');
    $kfz       = sanitize_text_field(isset($_POST['kennzeichen'])  ? $_POST['kennzeichen']  : '');
    $modell    = sanitize_text_field(isset($_POST['marke_modell']) ? $_POST['marke_modell'] : '');
    $reinigung = sanitize_text_field(isset($_POST['reinigung'])    ? $_POST['reinigung']    : 'keine');
    $days      = (int)(isset($_POST['days'])  ? $_POST['days']  : 0);
    $price     = number_format((float)(isset($_POST['price']) ? $_POST['price'] : 0), 2, ',', '.');
    $zahlung   = sanitize_text_field(isset($_POST['zahlungsart'])  ? $_POST['zahlungsart']  : '');
    $ref       = strtoupper(substr(md5($email . $anreise . time()), 0, 8));
    $name      = trim($vorname . ' ' . $nachname);
    if (!$name) $name = 'Kunde';

    $parkart_label = ($parkart === 'freiflaeche') ? 'Freiflächenpark' : 'Parkhaus (überdacht)';
    $zahlung_label = ($zahlung === 'online') ? 'Online (Zahlungslink per E-Mail)' : 'Bar bei Fahrzeugübergabe';

    $rein_labels = array();
    if (strpos($reinigung, 'aussen') !== false) $rein_labels[] = 'Außenreinigung';
    if (strpos($reinigung, 'innen')  !== false) $rein_labels[] = 'Innenreinigung';
    $rein_text = $rein_labels ? implode(' + ', $rein_labels) : 'Keine';

    $days_text = $days . ' Tag' . ($days !== 1 ? 'e' : '');

    $subject  = get_option('tvd_booking_email_subject', 'Buchungsbestätigung – Travel Valet Düsseldorf');
    $reply_to = get_option('tvd_booking_email_reply', get_option('admin_email'));
    $from_email = get_option('admin_email');

    $rows_html = '';
    $rows = array(
        array('📅 Anreise',    $anreise . ' um ' . $ankunft . ' Uhr'),
        array('🛬 Abreise',    $abreise . ' um ' . $lande   . ' Uhr'),
        array('🕐 Dauer',      $days_text),
        array('🚗 Parkart',    $parkart_label),
        array('🔑 Kennzeichen',$kfz),
        array('🚙 Fahrzeug',   $modell),
        array('🧹 Reinigung',  $rein_text),
        array('💳 Zahlung',    $zahlung_label),
        array('💰 Gesamtpreis','€' . $price),
    );
    foreach ($rows as $i => $row) {
        $bg = ($i % 2 === 0) ? '#ffffff' : '#f8f9fc';
        $rows_html .= '<tr style="background:' . $bg . ';">';
        $rows_html .= '<td style="padding:10px 12px;color:#6b7a99;font-size:13px;">' . esc_html($row[0]) . '</td>';
        $rows_html .= '<td style="padding:10px 12px;color:#1a2035;font-size:13px;font-weight:600;text-align:right;">' . esc_html($row[1]) . '</td>';
        $rows_html .= '</tr>';
    }

    $html = '<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8"></head><body style="margin:0;padding:0;background:#f4f6f9;font-family:Arial,sans-serif;">';
    $html .= '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f6f9;padding:32px 16px;"><tr><td align="center">';
    $html .= '<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,.08);">';
    $html .= '<tr><td style="background:linear-gradient(135deg,#0b0f1a,#13192b);padding:32px 40px;text-align:center;">';
    $html .= '<div style="font-size:28px;margin-bottom:8px;">✈️</div>';
    $html .= '<div style="color:#c9a84c;font-size:22px;font-weight:700;">Travel Valet Düsseldorf</div>';
    $html .= '<div style="color:#8b9bb4;font-size:13px;margin-top:4px;">Valet Parken · Flughafen DUS</div>';
    $html .= '</td></tr>';
    $html .= '<tr><td style="background:#c9a84c;padding:16px 40px;text-align:center;">';
    $html .= '<div style="color:#0b0f1a;font-size:18px;font-weight:700;">✓ Buchung bestätigt!</div>';
    $html .= '<div style="color:#0b0f1a;font-size:13px;margin-top:4px;">Referenznummer: <strong>TVD-' . $ref . '</strong></div>';
    $html .= '</td></tr>';
    $html .= '<tr><td style="padding:32px 40px 16px;">';
    $html .= '<p style="margin:0;color:#1a2035;font-size:16px;">Guten Tag, <strong>' . esc_html($name) . '</strong>,</p>';
    $html .= '<p style="margin:12px 0 0;color:#4b5675;font-size:14px;line-height:1.6;">vielen Dank für Ihre Buchung! Unser Fahrer wird zum vereinbarten Zeitpunkt am Terminal auf Sie warten.</p>';
    $html .= '</td></tr>';
    $html .= '<tr><td style="padding:8px 40px 32px;">';
    $html .= '<div style="background:#f8f9fc;border-radius:12px;padding:24px;border:1px solid #e8ecf4;">';
    $html .= '<div style="font-size:13px;font-weight:700;color:#8b9bb4;text-transform:uppercase;letter-spacing:.08em;margin-bottom:16px;">Ihre Buchungsdetails</div>';
    $html .= '<table width="100%" cellpadding="0" cellspacing="0">' . $rows_html . '</table>';
    $html .= '</div></td></tr>';
    $html .= '<tr><td style="padding:0 40px 32px;">';
    $html .= '<div style="background:#fffbf0;border:1px solid #f0d080;border-radius:12px;padding:20px;font-size:13px;color:#7a6020;line-height:1.6;">';
    $html .= '<strong>📍 Treffpunkt:</strong> Terminal des Flughafen Düsseldorf (DUS)<br>';
    $html .= 'Unser Fahrer hält ein Schild mit Ihrem Namen. Bitte halten Sie Ihr Kennzeichen (<strong>' . esc_html($kfz) . '</strong>) bereit.<br><br>';
    $html .= '<strong>📞 Bei Fragen:</strong> <a href="mailto:info.travelpark24@gmail.com" style="color:#c9a84c;">info.travelpark24@gmail.com</a>';
    $html .= '</div></td></tr>';
    $html .= '<tr><td style="background:#f8f9fc;padding:24px 40px;text-align:center;border-top:1px solid #e8ecf4;">';
    $html .= '<div style="font-size:12px;color:#8b9bb4;">Travel Valet Düsseldorf · Flughafen DUS<br>';
    $html .= '<a href="mailto:info.travelpark24@gmail.com" style="color:#c9a84c;text-decoration:none;">info.travelpark24@gmail.com</a></div>';
    $html .= '</td></tr></table></td></tr></table></body></html>';

    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'Reply-To: ' . $reply_to,
        'From: Travel Valet Düsseldorf <' . $from_email . '>',
    );

    wp_mail($email, $subject, $html, $headers);

    return $args;
}

/* ──────────────────────────────────────────────
   Frontend injection
────────────────────────────────────────────── */
add_action('wp_footer', 'tvd_inject_frontend', 99);
function tvd_inject_frontend() {
    $sections_raw = get_option('tvd_sections', null);
    $sections     = $sections_raw ? json_decode($sections_raw, true) : array();
    usort($sections, function($a, $b) { return (isset($a['order']) ? $a['order'] : 0) - (isset($b['order']) ? $b['order'] : 0); });

    $logo_type = get_option('tvd_logo_type', 'svg');
    $logo_url  = get_option('tvd_logo_url', '');
    $pp_embed  = get_option('tvd_parkingpro_embed', '');

    $sections_json = json_encode($sections);
    $logo_type_js  = json_encode($logo_type);
    $logo_url_js   = json_encode($logo_url);
    $pp_embed_js   = json_encode($pp_embed);

    echo '<script>' . "\n";
    echo '(function(){' . "\n";
    echo 'var sections = ' . $sections_json . ';' . "\n";
    echo 'if(sections&&sections.length){';
    echo 'sections.forEach(function(s){var el=document.getElementById(s.id);if(el)el.style.display=s.visible?"":"none";});';
    echo 'var ordered=sections.filter(function(s){return s.visible;}).map(function(s){return document.getElementById(s.id);}).filter(Boolean);';
    echo 'if(ordered.length>1){var parent=ordered[0].parentNode;if(parent)ordered.forEach(function(el){parent.appendChild(el);});}';
    echo '}' . "\n";
    echo 'var logoType=' . $logo_type_js . ';';
    echo 'var logoUrl=' . $logo_url_js . ';';
    echo 'var brand=document.querySelector(".navbar-brand,.tvd-logo,[class*=\"brand\"]");';
    echo 'if(brand){var span=document.createElement("span");span.className="tvd-injected-logo";';
    echo 'span.style.cssText="display:inline-flex;align-items:center;margin-left:8px;vertical-align:middle;";';
    echo 'if(logoType==="url"&&logoUrl){var img=document.createElement("img");img.src=logoUrl;img.style.cssText="height:36px;width:auto;object-fit:contain;";img.alt="Logo";span.appendChild(img);}';
    echo 'else{span.innerHTML=\'<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.8 19.2L16 11l3.5-3.5C21 6 21 4 19.5 2.5c-1.5-1.5-3.5-1.5-5 0L11 6 2.8 4.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 6.2 7.3c.4.4.9.5 1.3.3l.5-.3c.4-.2.6-.7.5-1.1z"/></svg>\';}';
    echo 'brand.insertBefore(span,brand.firstChild);}' . "\n";
    echo 'var ppEmbed=' . $pp_embed_js . ';';
    echo 'var ppSec=document.getElementById("parkingpro");';
    echo 'if(!ppSec){ppSec=document.createElement("section");ppSec.id="parkingpro";ppSec.className="tvd-section tvd-bg-light";document.body.appendChild(ppSec);}';
    echo 'if(ppEmbed)ppSec.innerHTML=\'<div class="tvd-container" style="padding:60px 20px;text-align:center;">\'+ppEmbed+\'</div>\';';
    echo '})();' . "\n";
    echo '</script>' . "\n";
}
