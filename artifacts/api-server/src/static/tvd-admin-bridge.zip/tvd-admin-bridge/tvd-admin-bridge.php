<?php
/**
 * Plugin Name: TVD Admin Bridge
 * Description: Bridge between TVD Admin Panel and WordPress
 * Version: 1.7.0
 * Author: Travel Valet Düsseldorf
 */

if (!defined('ABSPATH')) exit;

/* ─── REST: Sections ─────────────────────────────────────────────────────── */
add_action('rest_api_init', function () {
    register_rest_route('tvd-admin/v1', '/sections', array(
        array('methods'=>'GET',  'callback'=>'tvd_get_sections',  'permission_callback'=>'__return_true'),
        array('methods'=>'POST', 'callback'=>'tvd_save_sections', 'permission_callback'=>'tvd_auth'),
    ));
    register_rest_route('tvd-admin/v1', '/parkingpro', array(
        array('methods'=>'GET',  'callback'=>'tvd_get_parkingpro',  'permission_callback'=>'__return_true'),
        array('methods'=>'POST', 'callback'=>'tvd_save_parkingpro', 'permission_callback'=>'tvd_auth'),
    ));
    register_rest_route('tvd-admin/v1', '/logo', array(
        array('methods'=>'GET',  'callback'=>'tvd_get_logo',  'permission_callback'=>'__return_true'),
        array('methods'=>'POST', 'callback'=>'tvd_save_logo', 'permission_callback'=>'tvd_auth'),
    ));
    register_rest_route('tvd-admin/v1', '/booking-email', array(
        array('methods'=>'GET',  'callback'=>'tvd_get_booking_email_settings',  'permission_callback'=>'tvd_auth'),
        array('methods'=>'POST', 'callback'=>'tvd_save_booking_email_settings', 'permission_callback'=>'tvd_auth'),
    ));
});

function tvd_auth() {
    $h = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
    if (!$h && function_exists('getallheaders')) {
        $all = getallheaders();
        $h = isset($all['Authorization']) ? $all['Authorization'] : (isset($all['authorization']) ? $all['authorization'] : '');
    }
    if (substr($h, 0, 6) !== 'Basic ') return false;
    $parts = explode(':', base64_decode(substr($h, 6)), 2);
    return isset($parts[0], $parts[1]) && $parts[0] === get_option('tvd_wp_user') && $parts[1] === get_option('tvd_wp_pass');
}

function tvd_get_sections() {
    $def = array(
        array('id'=>'home',       'label'=>'القسم الرئيسي',                      'visible'=>true,'order'=>0),
        array('id'=>'tvd-stats',  'label'=>'الإحصائيات (24/7 · 5★ · 2min · 100%)','visible'=>true,'order'=>1),
        array('id'=>'buchen',     'label'=>'الحجز',                               'visible'=>true,'order'=>2),
        array('id'=>'services',   'label'=>'الخدمات',                             'visible'=>true,'order'=>3),
        array('id'=>'ablauf',     'label'=>'كيف يعمل',                            'visible'=>true,'order'=>4),
        array('id'=>'parkingpro', 'label'=>'احجز الآن - ParkingPro',              'visible'=>true,'order'=>5),
        array('id'=>'ueber-uns',  'label'=>'من نحن',                              'visible'=>true,'order'=>6),
        array('id'=>'kontakt',    'label'=>'تواصل معنا',                          'visible'=>true,'order'=>7),
    );
    $saved = get_option('tvd_sections', null);
    return new WP_REST_Response(array('sections' => $saved !== null ? json_decode($saved, true) : $def));
}
function tvd_save_sections($req) {
    update_option('tvd_sections', json_encode($req->get_param('sections')));
    return new WP_REST_Response(array('ok'=>true));
}
function tvd_get_parkingpro() {
    return new WP_REST_Response(array('embed'=>get_option('tvd_parkingpro_embed', '')));
}
function tvd_save_parkingpro($req) {
    update_option('tvd_parkingpro_embed', $req->get_param('embed'));
    return new WP_REST_Response(array('ok'=>true));
}
function tvd_get_logo() {
    return new WP_REST_Response(array('type'=>get_option('tvd_logo_type','svg'),'url'=>get_option('tvd_logo_url','')));
}
function tvd_save_logo($req) {
    update_option('tvd_logo_type', $req->get_param('type'));
    update_option('tvd_logo_url',  $req->get_param('url'));
    return new WP_REST_Response(array('ok'=>true));
}
function tvd_get_booking_email_settings() {
    return new WP_REST_Response(array(
        'enabled'  => (bool)get_option('tvd_booking_email_enabled', 1),
        'subject'  => get_option('tvd_booking_email_subject', 'Buchungsbestätigung – Travel Valet Düsseldorf'),
        'reply_to' => get_option('tvd_booking_email_reply', get_option('admin_email')),
    ));
}
function tvd_save_booking_email_settings($req) {
    update_option('tvd_booking_email_enabled', $req->get_param('enabled') ? 1 : 0);
    $s = $req->get_param('subject');   if ($s) update_option('tvd_booking_email_subject', sanitize_text_field($s));
    $r = $req->get_param('reply_to');  if ($r) update_option('tvd_booking_email_reply',   sanitize_email($r));
    return new WP_REST_Response(array('ok'=>true));
}

/* ─── AJAX: Customer confirmation email ──────────────────────────────────── */
add_action('wp_ajax_nopriv_tvd_bridge_send_confirm', 'tvd_handle_confirm_email');
add_action('wp_ajax_tvd_bridge_send_confirm',        'tvd_handle_confirm_email');

function tvd_handle_confirm_email() {
    if (!get_option('tvd_booking_email_enabled', 1)) { wp_send_json_success(); return; }

    $email    = sanitize_email(isset($_POST['email'])        ? $_POST['email']        : '');
    $vorname  = sanitize_text_field(isset($_POST['vorname']) ? $_POST['vorname']      : '');
    $nachname = sanitize_text_field(isset($_POST['nachname'])? $_POST['nachname']     : '');
    $anreise  = sanitize_text_field(isset($_POST['anreise']) ? $_POST['anreise']      : '');
    $ankunft  = sanitize_text_field(isset($_POST['ankunft']) ? $_POST['ankunft']      : '');
    $abreise  = sanitize_text_field(isset($_POST['abreise']) ? $_POST['abreise']      : '');
    $lande    = sanitize_text_field(isset($_POST['lande'])   ? $_POST['lande']        : '');
    $parkart  = sanitize_text_field(isset($_POST['parkart']) ? $_POST['parkart']      : '');
    $kfz      = sanitize_text_field(isset($_POST['kfz'])     ? $_POST['kfz']          : '');
    $modell   = sanitize_text_field(isset($_POST['modell'])  ? $_POST['modell']       : '');
    $rein     = sanitize_text_field(isset($_POST['rein'])    ? $_POST['rein']         : 'keine');
    $days     = (int)(isset($_POST['days'])  ? $_POST['days']  : 0);
    $price    = number_format((float)(isset($_POST['price']) ? $_POST['price'] : 0), 2, ',', '.');
    $zahlung  = sanitize_text_field(isset($_POST['zahlung']) ? $_POST['zahlung']      : '');

    if (!$email) { wp_send_json_error('no email'); return; }

    $ref   = strtoupper(substr(md5($email . $anreise . time()), 0, 8));
    $name  = trim($vorname . ' ' . $nachname); if (!$name) $name = 'Kunde';
    $pl    = ($parkart === 'freiflaeche') ? 'Freiflächenpark' : 'Parkhaus (überdacht)';
    $zl    = ($zahlung === 'online') ? 'Online (Zahlungslink per E-Mail)' : 'Bar bei Fahrzeugübergabe';
    $rl_a  = array();
    if (strpos($rein, 'aussen') !== false) $rl_a[] = 'Außenreinigung';
    if (strpos($rein, 'innen')  !== false) $rl_a[] = 'Innenreinigung';
    $rl    = $rl_a ? implode(' + ', $rl_a) : 'Keine';
    $dt    = $days . ' Tag' . ($days !== 1 ? 'e' : '');

    $rows  = array(
        array('📅 Anreise',    $anreise . ' um ' . $ankunft . ' Uhr'),
        array('🛬 Abreise',    $abreise . ' um ' . $lande   . ' Uhr'),
        array('🕐 Dauer',      $dt),
        array('🚗 Parkart',    $pl),
        array('🔑 Kennzeichen',$kfz),
        array('🚙 Fahrzeug',   $modell),
        array('🧹 Reinigung',  $rl),
        array('💳 Zahlung',    $zl),
        array('💰 Gesamtpreis','€' . $price),
    );
    $rows_html = '';
    foreach ($rows as $i => $row) {
        $bg = ($i % 2 === 0) ? '#ffffff' : '#f8f9fc';
        $rows_html .= '<tr style="background:' . $bg . ';">';
        $rows_html .= '<td style="padding:10px 12px;color:#6b7a99;font-size:13px;">' . esc_html($row[0]) . '</td>';
        $rows_html .= '<td style="padding:10px 12px;color:#1a2035;font-size:13px;font-weight:600;text-align:right;">' . esc_html($row[1]) . '</td>';
        $rows_html .= '</tr>';
    }

    $html  = '<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8"></head><body style="margin:0;padding:0;background:#f4f6f9;font-family:Arial,sans-serif;">';
    $html .= '<table width="100%" cellpadding="0" cellspacing="0" style="padding:32px 16px;"><tr><td align="center">';
    $html .= '<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#fff;border-radius:16px;overflow:hidden;">';
    $html .= '<tr><td style="background:linear-gradient(135deg,#0b0f1a,#13192b);padding:32px 40px;text-align:center;">';
    $html .= '<div style="font-size:28px;">✈️</div>';
    $html .= '<div style="color:#c9a84c;font-size:22px;font-weight:700;margin-top:8px;">Travel Valet Düsseldorf</div>';
    $html .= '<div style="color:#8b9bb4;font-size:13px;margin-top:4px;">Valet Parken · Flughafen DUS</div>';
    $html .= '</td></tr>';
    $html .= '<tr><td style="background:#c9a84c;padding:16px 40px;text-align:center;">';
    $html .= '<div style="color:#0b0f1a;font-size:18px;font-weight:700;">&#10003; Buchung bestätigt!</div>';
    $html .= '<div style="color:#0b0f1a;font-size:13px;margin-top:4px;">Referenznummer: <strong>TVD-' . $ref . '</strong></div>';
    $html .= '</td></tr>';
    $html .= '<tr><td style="padding:32px 40px 16px;">';
    $html .= '<p style="margin:0;color:#1a2035;font-size:16px;">Guten Tag, <strong>' . esc_html($name) . '</strong>,</p>';
    $html .= '<p style="margin:12px 0 0;color:#4b5675;font-size:14px;line-height:1.6;">vielen Dank für Ihre Buchung! Unser Fahrer wird zum vereinbarten Zeitpunkt am Terminal auf Sie warten.</p>';
    $html .= '</td></tr>';
    $html .= '<tr><td style="padding:8px 40px 32px;">';
    $html .= '<div style="background:#f8f9fc;border-radius:12px;padding:24px;border:1px solid #e8ecf4;">';
    $html .= '<div style="font-size:13px;font-weight:700;color:#8b9bb4;text-transform:uppercase;margin-bottom:16px;">Ihre Buchungsdetails</div>';
    $html .= '<table width="100%" cellpadding="0" cellspacing="0">' . $rows_html . '</table>';
    $html .= '</div></td></tr>';
    $html .= '<tr><td style="padding:0 40px 32px;">';
    $html .= '<div style="background:#fffbf0;border:1px solid #f0d080;border-radius:12px;padding:20px;font-size:13px;color:#7a6020;line-height:1.6;">';
    $html .= '<strong>Treffpunkt:</strong> Terminal Flughafen Düsseldorf (DUS) — Fahrer hält Schild mit Ihrem Namen.<br><br>';
    $html .= '<strong>Fragen?</strong> <a href="mailto:info.travelpark24@gmail.com" style="color:#c9a84c;">info.travelpark24@gmail.com</a>';
    $html .= '</div></td></tr>';
    $html .= '<tr><td style="background:#f8f9fc;padding:24px 40px;text-align:center;border-top:1px solid #e8ecf4;">';
    $html .= '<div style="font-size:12px;color:#8b9bb4;">Travel Valet Düsseldorf · <a href="mailto:info.travelpark24@gmail.com" style="color:#c9a84c;">info.travelpark24@gmail.com</a></div>';
    $html .= '</td></tr></table></td></tr></table></body></html>';

    $subject  = get_option('tvd_booking_email_subject', 'Buchungsbestätigung – Travel Valet Düsseldorf');
    $reply_to = get_option('tvd_booking_email_reply', get_option('admin_email'));
    $headers  = array(
        'Content-Type: text/html; charset=UTF-8',
        'Reply-To: ' . $reply_to,
        'From: Travel Valet Dusseldorf <' . get_option('admin_email') . '>',
    );

    wp_mail($email, $subject, $html, $headers);
    wp_send_json_success();
}

/* ─── Frontend injection ──────────────────────────────────────────────────── */
add_action('wp_footer', 'tvd_inject_frontend', 99);
function tvd_inject_frontend() {
    $sections_raw = get_option('tvd_sections', null);
    $sections     = $sections_raw ? json_decode($sections_raw, true) : array();
    usort($sections, function($a,$b){ return (isset($a['order'])?$a['order']:0)-(isset($b['order'])?$b['order']:0); });

    $logo_type = get_option('tvd_logo_type', 'svg');
    $logo_url  = get_option('tvd_logo_url', '');
    $pp_embed  = get_option('tvd_parkingpro_embed', '');
    $ajax_url  = admin_url('admin-ajax.php');
    $enabled   = get_option('tvd_booking_email_enabled', 1) ? 'true' : 'false';

    $sj = json_encode($sections);
    $lt = json_encode($logo_type);
    $lu = json_encode($logo_url);
    $pp = json_encode($pp_embed);
    $aj = json_encode($ajax_url);

    echo '<script>' . "\n";
    echo '(function(){' . "\n";

    /* sections */
    echo 'var S=' . $sj . ';';
    echo 'if(S&&S.length){';
    echo 'S.forEach(function(s){var e=document.getElementById(s.id);if(e)e.style.display=s.visible?"":"none";});';
    echo 'var o=S.filter(function(s){return s.visible;}).map(function(s){return document.getElementById(s.id);}).filter(Boolean);';
    echo 'if(o.length>1){var p=o[0].parentNode;if(p)o.forEach(function(e){p.appendChild(e);});}';
    echo '}' . "\n";

    /* logo */
    echo 'var lt=' . $lt . ',lu=' . $lu . ';';
    echo 'var br=document.querySelector(".navbar-brand,.tvd-logo,[class*=\'brand\']");';
    echo 'if(br&&!br.querySelector(".tvd-injected-logo")){';
    echo 'var sp=document.createElement("span");sp.className="tvd-injected-logo";';
    echo 'sp.style.cssText="display:inline-flex;align-items:center;margin-left:8px;vertical-align:middle;";';
    echo 'if(lt==="url"&&lu){var im=document.createElement("img");im.src=lu;im.style.cssText="height:36px;width:auto;";im.alt="Logo";sp.appendChild(im);}';
    echo 'else{sp.innerHTML=\'<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.8 19.2L16 11l3.5-3.5C21 6 21 4 19.5 2.5c-1.5-1.5-3.5-1.5-5 0L11 6 2.8 4.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 6.2 7.3c.4.4.9.5 1.3.3l.5-.3c.4-.2.6-.7.5-1.1z"/></svg>\';}';
    echo 'br.insertBefore(sp,br.firstChild);}' . "\n";

    /* parkingpro */
    echo 'var pp=' . $pp . ';';
    echo 'var ps=document.getElementById("parkingpro");';
    echo 'if(!ps){ps=document.createElement("section");ps.id="parkingpro";ps.className="tvd-section tvd-bg-light";document.body.appendChild(ps);}';
    echo 'if(pp)ps.innerHTML=\'<div class="tvd-container" style="padding:60px 20px;text-align:center;">\'+pp+\'</div>\';' . "\n";

    /* customer confirmation email — wrap tvdSubmit */
    echo 'var tvdAjax=' . $aj . ';';
    echo 'var emailEnabled=' . $enabled . ';';
    echo 'if(emailEnabled&&typeof window.tvdSubmit==="function"){';
    echo '  var _orig=window.tvdSubmit;';
    echo '  window.tvdSubmit=function(){';
    echo '    var _fetch=window.fetch;';
    echo '    window.fetch=function(url,opts){';
    echo '      return _fetch(url,opts).then(function(r){';
    echo '        var clone=r.clone();';
    echo '        clone.json().then(function(res){';
    echo '          if(res&&res.success){';
    echo '            var fd=new FormData();';
    echo '            fd.append("action","tvd_bridge_send_confirm");';
    echo '            fd.append("email",document.getElementById("tvd_email")?document.getElementById("tvd_email").value:"");';
    echo '            fd.append("vorname",document.getElementById("tvd_vorname")?document.getElementById("tvd_vorname").value:"");';
    echo '            fd.append("nachname",document.getElementById("tvd_nachname")?document.getElementById("tvd_nachname").value:"");';
    echo '            fd.append("anreise",document.getElementById("tvd_anreise")?document.getElementById("tvd_anreise").value:"");';
    echo '            fd.append("ankunft",document.getElementById("tvd_ankunft")?document.getElementById("tvd_ankunft").value:"");';
    echo '            fd.append("abreise",document.getElementById("tvd_abreise")?document.getElementById("tvd_abreise").value:"");';
    echo '            fd.append("lande",document.getElementById("tvd_lande")?document.getElementById("tvd_lande").value:"");';
    echo '            fd.append("kfz",document.getElementById("tvd_kennzeichen")?document.getElementById("tvd_kennzeichen").value:"");';
    echo '            fd.append("modell",document.getElementById("tvd_modell")?document.getElementById("tvd_modell").value:"");';
    echo '            if(typeof parkart!=="undefined")fd.append("parkart",parkart);';
    echo '            if(typeof rein_a!=="undefined"&&typeof rein_i!=="undefined"){var ri=[];if(rein_a)ri.push("aussen");if(rein_i)ri.push("innen");fd.append("rein",ri.join("+"));}';
    echo '            if(typeof calcPrice==="function"){var cp=calcPrice();fd.append("days",cp.days);fd.append("price",cp.total.toFixed(2));}';
    echo '            if(typeof payOpt!=="undefined")fd.append("zahlung",payOpt);';
    echo '            _fetch(tvdAjax,{method:"POST",body:fd}).catch(function(){});';
    echo '          }';
    echo '          window.fetch=_fetch;';
    echo '        }).catch(function(){window.fetch=_fetch;});';
    echo '        return r;';
    echo '      });';
    echo '    };';
    echo '    _orig();';
    echo '  };';
    echo '}' . "\n";

    echo '})();' . "\n";
    echo '</script>' . "\n";
}
