<?php
/**
 * Plugin Name: TVD Buchungssystem
 * Description: Buchungsformular, E-Mails und Admin-Panel fuer Travel Valet Duesseldorf
 * Version: 1.0.1
 * Author: Travel Valet Duesseldorf
 */
if (!defined('ABSPATH')) exit;

function tvd_create_table() {
    global $wpdb;
    $t = $wpdb->prefix . 'tvd_bookings';
    $c = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $t (
        id INT AUTO_INCREMENT PRIMARY KEY,
        vorname VARCHAR(100), nachname VARCHAR(100), email VARCHAR(200), telefon VARCHAR(50),
        kennzeichen VARCHAR(50), marke_modell VARCHAR(100), farbe VARCHAR(50),
        anreise_datum DATE, ankunftszeit VARCHAR(20), abreise_datum DATE, landezeit VARCHAR(20),
        rueckflug VARCHAR(50), parkart VARCHAR(50), fahrzeuglaenge VARCHAR(50),
        reinigung VARCHAR(50), days INT, price DECIMAL(10,2), zahlungsart VARCHAR(50),
        status VARCHAR(30) DEFAULT 'neu', created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $c;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'tvd_create_table');

function tvd_booking_form_shortcode() {
    $p = [
        'freiflaeche'      => (int) get_option('tvd_price_freiflaeche', 1200),
        'parkhaus'         => (int) get_option('tvd_price_parkhaus', 1500),
        'reinigung_aussen' => (int) get_option('tvd_price_reinigung_aussen', 4000),
        'reinigung_innen'  => (int) get_option('tvd_price_reinigung_innen', 7000),
    ];
    ob_start(); ?>
<div id="tvd-booking-wrap" style="background:#13192b;border-radius:20px;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,.5);">
  <div style="background:linear-gradient(135deg,#c9a84c,#f0d080,#c9a84c);padding:24px 28px;display:flex;align-items:center;gap:16px;">
    <div style="width:48px;height:48px;background:#0b0f1a;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;">🚗</div>
    <div><div style="font-size:16px;font-weight:700;color:#0b0f1a;"><?php echo esc_html(get_theme_mod('tvd_logo_text','Travel Valet')); ?> <?php echo esc_html(get_theme_mod('tvd_logo_gold','Düsseldorf')); ?></div><div style="font-size:12px;color:#0b0f1a;opacity:.7;">Valet Parken · Flughafen DUS</div></div>
  </div>
  <div id="tvd-steps-bar" style="display:flex;align-items:center;padding:20px 28px;background:#0b0f1a;gap:8px;">
    <?php foreach([['📅','Parkinfos'],['👤','Pers. Daten'],['📋','Übersicht'],['💳','Zahlung']] as $i=>$s):$n=$i+1;?>
    <div class="tvd-step-item" data-step="<?php echo $n;?>" style="display:flex;flex-direction:column;align-items:center;gap:4px;flex:1;">
      <div class="tvd-step-dot" style="width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;transition:all .3s;background:<?php echo $n==1?'linear-gradient(135deg,#c9a84c,#f0d080)':'rgba(255,255,255,.08)';?>;color:<?php echo $n==1?'#0b0f1a':'#6b7280';?>;"><?php echo $s[0];?></div>
      <div class="tvd-step-label" style="font-size:10px;font-weight:600;color:<?php echo $n==1?'#c9a84c':'#6b7280';?>;white-space:nowrap;"><?php echo $s[1];?></div>
    </div>
    <?php if($i<3):?><div style="flex:1;height:1px;background:#1e2940;margin-bottom:20px;"></div><?php endif;?>
    <?php endforeach;?>
  </div>
  <div style="padding:24px 28px;">
    <div id="tvd-step-1" class="tvd-step-content">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">
        <?php foreach([['tvd_anreise','Anreisedatum *','date'],['tvd_abreise','Abreisedatum *','date'],['tvd_ankunft','Ankunftszeit *','time'],['tvd_lande','Landezeit *','time']] as $f):?>
        <div>
          <label style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#6b7280;display:block;margin-bottom:6px;"><?php echo $f[1];?></label>
          <input type="<?php echo $f[2];?>" id="<?php echo $f[0];?>" style="width:100%;background:#1e2940;border:1.5px solid #2a3550;color:#e8eaf0;padding:12px 14px;border-radius:12px;font-size:14px;outline:none;box-sizing:border-box;" onfocus="this.style.borderColor='#c9a84c'" onblur="this.style.borderColor='#2a3550'">
        </div>
        <?php endforeach;?>
      </div>
      <div style="margin-bottom:14px;">
        <label style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#6b7280;display:block;margin-bottom:6px;">Rückflugnummer</label>
        <input type="text" id="tvd_rueckflug" placeholder="z.B. LH 1234" style="width:100%;background:#1e2940;border:1.5px solid #2a3550;color:#e8eaf0;padding:12px 14px;border-radius:12px;font-size:14px;outline:none;box-sizing:border-box;" onfocus="this.style.borderColor='#c9a84c'" onblur="this.style.borderColor='#2a3550'">
      </div>
      <div style="margin-bottom:14px;">
        <p style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#6b7280;margin:0 0 10px;">Stellplatz *</p>
        <?php foreach([['freifl%C3%A4che','Freifläche','Überdachter Außenbereich','freiflaeche'],['parkhaus','Parkhaus','Vollständig überdacht','parkhaus']] as $pk):?>
        <label class="tvd-parkart-opt" data-val="<?php echo urldecode($pk[0]);?>" style="display:flex;align-items:center;gap:12px;padding:14px 16px;border-radius:14px;cursor:pointer;margin-bottom:8px;background:#1e2940;border:1.5px solid #2a3550;transition:all .2s;">
          <input type="radio" name="tvd_parkart" value="<?php echo urldecode($pk[0]);?>" style="display:none;">
          <span style="flex:1;"><span style="display:block;font-size:13px;font-weight:600;color:#e8eaf0;"><?php echo $pk[1];?></span><span style="font-size:11px;color:#6b7280;"><?php echo $pk[2];?></span></span>
          <span style="font-size:12px;font-weight:700;color:#c9a84c;">€<?php echo number_format($p[$pk[3]]/100,0);?>/Tag</span>
        </label>
        <?php endforeach;?>
      </div>
      <div style="margin-bottom:14px;">
        <label style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#6b7280;display:block;margin-bottom:6px;">Fahrzeuglänge</label>
        <select id="tvd_laenge" style="width:100%;background:#1e2940;border:1.5px solid #2a3550;color:#e8eaf0;padding:12px 14px;border-radius:12px;font-size:14px;outline:none;box-sizing:border-box;" onfocus="this.style.borderColor='#c9a84c'" onblur="this.style.borderColor='#2a3550'">
          <option value="">Bitte wählen</option>
          <?php foreach(['Bis 4,50 m','4,50 m – 5,00 m','5,00 m – 5,50 m','Über 5,50 m'] as $l):?>
          <option><?php echo $l;?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div style="margin-bottom:14px;">
        <p style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#6b7280;margin:0 0 10px;">Reinigung</p>
        <?php foreach([['aussen','Außenreinigung','reinigung_aussen'],['innen','Innenreinigung','reinigung_innen']] as $r):?>
        <label class="tvd-rein-opt" data-val="<?php echo $r[0];?>" style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-radius:12px;cursor:pointer;margin-bottom:8px;background:#1e2940;border:1.5px solid #2a3550;transition:all .2s;">
          <input type="checkbox" name="tvd_rein[]" value="<?php echo $r[0];?>" style="display:none;">
          <span class="tvd-checkbox-box" style="width:16px;height:16px;border-radius:4px;border:2px solid #4a5568;background:transparent;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s;"></span>
          <span style="flex:1;font-size:13px;font-weight:500;color:#e8eaf0;"><?php echo $r[1];?></span>
          <span style="font-size:12px;font-weight:700;color:#c9a84c;">€<?php echo number_format($p[$r[2]]/100,0);?></span>
        </label>
        <?php endforeach;?>
        <label class="tvd-keine-rein" style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-radius:12px;cursor:pointer;background:rgba(201,168,76,.08);border:1.5px solid #c9a84c;">
          <span class="tvd-keine-dot" style="width:16px;height:16px;border-radius:50%;border:2px solid #c9a84c;background:#c9a84c;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><span style="width:6px;height:6px;border-radius:50%;background:#fff;display:block;"></span></span>
          <span style="font-size:13px;font-weight:500;color:#c9a84c;">Keine Reinigung erforderlich</span>
        </label>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:20px;">
        <div style="background:#1e2940;border:1px solid #2a3550;border-radius:12px;padding:14px;text-align:center;"><div style="font-size:10px;text-transform:uppercase;color:#4a5568;margin-bottom:4px;">Dauer</div><div id="tvd_days_display" style="font-size:26px;font-weight:700;color:#e8eaf0;">0</div><div style="font-size:11px;color:#6b7280;">Tage</div></div>
        <div style="background:#1e2940;border:1px solid #2a3550;border-radius:12px;padding:14px;text-align:center;"><div style="font-size:10px;text-transform:uppercase;color:#4a5568;margin-bottom:4px;">Preis</div><div id="tvd_price_display" style="font-size:26px;font-weight:700;color:#c9a84c;">0.00</div><div style="font-size:11px;color:#6b7280;">€</div></div>
      </div>
      <button onclick="tvdNextStep(1)" style="width:100%;background:linear-gradient(135deg,#c9a84c,#f0d080);color:#0b0f1a;font-weight:700;padding:16px;border:none;cursor:pointer;border-radius:14px;font-size:15px;">Weiter →</button>
    </div>
    <div id="tvd-step-2" class="tvd-step-content" style="display:none;">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px;">
        <?php foreach([['tvd_vorname','Vorname *','text'],['tvd_nachname','Nachname *','text'],['tvd_email','E-Mail *','email'],['tvd_telefon','Telefon *','tel'],['tvd_kennzeichen','Kennzeichen *','text'],['tvd_modell','Marke & Modell *','text'],['tvd_farbe','Fahrzeugfarbe','text']] as $f):?>
        <div><label style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#6b7280;display:block;margin-bottom:6px;"><?php echo $f[1];?></label><input type="<?php echo $f[2];?>" id="<?php echo $f[0];?>" style="width:100%;background:#1e2940;border:1.5px solid #2a3550;color:#e8eaf0;padding:12px 14px;border-radius:12px;font-size:14px;outline:none;box-sizing:border-box;" onfocus="this.style.borderColor='#c9a84c'" onblur="this.style.borderColor='#2a3550'"></div>
        <?php endforeach;?>
      </div>
      <div style="display:flex;gap:12px;"><button onclick="tvdNextStep(-1)" style="flex:1;background:#1e2940;color:#9ca3af;font-weight:600;padding:14px;border:1.5px solid #2a3550;cursor:pointer;border-radius:14px;">← Zurück</button><button onclick="tvdNextStep(2)" style="flex:2;background:linear-gradient(135deg,#c9a84c,#f0d080);color:#0b0f1a;font-weight:700;padding:14px;border:none;cursor:pointer;border-radius:14px;">Weiter →</button></div>
    </div>
    <div id="tvd-step-3" class="tvd-step-content" style="display:none;">
      <div id="tvd-summary" style="background:#1e2940;border-radius:14px;padding:20px;margin-bottom:20px;font-size:13px;color:#9ca3af;line-height:2;"></div>
      <div style="display:flex;gap:12px;"><button onclick="tvdNextStep(-1)" style="flex:1;background:#1e2940;color:#9ca3af;font-weight:600;padding:14px;border:1.5px solid #2a3550;cursor:pointer;border-radius:14px;">← Zurück</button><button onclick="tvdNextStep(3)" style="flex:2;background:linear-gradient(135deg,#c9a84c,#f0d080);color:#0b0f1a;font-weight:700;padding:14px;border:none;cursor:pointer;border-radius:14px;">Weiter →</button></div>
    </div>
    <div id="tvd-step-4" class="tvd-step-content" style="display:none;">
      <?php foreach([['bar','Zahlung vor Ort (Bar)','In bar direkt am Terminal.'],['online','Online Zahlung','E-Mail mit Zahlungslink.']] as $pay):?>
      <label class="tvd-pay-opt" data-val="<?php echo $pay[0];?>" style="display:flex;align-items:center;gap:16px;padding:16px 20px;border-radius:14px;cursor:pointer;margin-bottom:10px;background:#1e2940;border:1.5px solid #2a3550;transition:all .2s;">
        <input type="radio" name="tvd_pay" value="<?php echo $pay[0];?>" style="display:none;">
        <span class="tvd-pay-dot" style="width:20px;height:20px;border-radius:50%;border:2px solid #4a5568;flex-shrink:0;display:flex;align-items:center;justify-content:center;transition:all .2s;"></span>
        <span><span style="display:block;font-size:13px;font-weight:600;color:#e8eaf0;"><?php echo $pay[1];?></span><span style="font-size:11px;color:#6b7280;"><?php echo $pay[2];?></span></span>
      </label>
      <?php endforeach;?>
      <div style="margin:16px 0;display:flex;flex-direction:column;gap:10px;">
        <label style="display:flex;align-items:flex-start;gap:12px;cursor:pointer;"><input type="checkbox" id="tvd_agb" style="margin-top:2px;accent-color:#c9a84c;"><span style="font-size:12px;color:#9ca3af;">Ich akzeptiere die <a href="#" style="color:#c9a84c;">AGB</a> und <a href="#" style="color:#c9a84c;">Datenschutzbestimmungen</a>.</span></label>
        <label style="display:flex;align-items:flex-start;gap:12px;cursor:pointer;"><input type="checkbox" id="tvd_richtig" style="margin-top:2px;accent-color:#c9a84c;"><span style="font-size:12px;color:#9ca3af;">Ich bestätige, dass alle Angaben korrekt sind.</span></label>
      </div>
      <div id="tvd-error" style="display:none;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:10px;padding:12px 16px;font-size:12px;color:#f87171;margin-bottom:12px;"></div>
      <div style="display:flex;gap:12px;"><button onclick="tvdNextStep(-1)" style="flex:1;background:#1e2940;color:#9ca3af;font-weight:600;padding:14px;border:1.5px solid #2a3550;cursor:pointer;border-radius:14px;">← Zurück</button><button id="tvd-submit-btn" onclick="tvdSubmit()" style="flex:2;background:linear-gradient(135deg,#c9a84c,#f0d080);color:#0b0f1a;font-weight:700;padding:14px;border:none;cursor:pointer;border-radius:14px;">Buchung abschicken</button></div>
    </div>
    <div id="tvd-success" style="display:none;text-align:center;padding:32px 0;">
      <div style="width:72px;height:72px;border-radius:50%;background:linear-gradient(135deg,#2d8a4e,#3aaf64);display:flex;align-items:center;justify-content:center;margin:0 auto 24px;font-size:32px;">✓</div>
      <h4 style="font-size:20px;font-weight:700;color:#e8eaf0;margin:0 0 12px;">Buchung bestätigt!</h4>
      <p id="tvd-success-pay" style="font-size:13px;color:#6b7280;margin:0 0 16px;"></p>
      <div style="background:rgba(201,168,76,.08);border:1px solid rgba(201,168,76,.3);border-radius:12px;padding:16px;margin-bottom:24px;text-align:left;">
        <p style="font-size:12px;line-height:1.8;color:#9ca3af;margin:0;"><strong style="color:#c9a84c;">📍 Treffpunkt:</strong> Fahren Sie direkt zum Abflugterminal des Flughafens Düsseldorf (DUS). <strong style="color:#c9a84c;">Terminal B&amp;C</strong></p>
      </div>
      <button onclick="location.reload()" style="font-size:13px;font-weight:600;color:#c9a84c;background:none;border:none;cursor:pointer;text-decoration:underline;">Neue Buchung starten</button>
    </div>
  </div>
</div>
<input type="hidden" id="tvd_nonce" value="<?php echo wp_create_nonce('tvd_booking_nonce');?>">
<input type="hidden" id="tvd_ajax_url" value="<?php echo admin_url('admin-ajax.php');?>">
<input type="hidden" id="tvd_pF" value="<?php echo $p['freiflaeche'];?>">
<input type="hidden" id="tvd_pP" value="<?php echo $p['parkhaus'];?>">
<input type="hidden" id="tvd_pRA" value="<?php echo $p['reinigung_aussen'];?>">
<input type="hidden" id="tvd_pRI" value="<?php echo $p['reinigung_innen'];?>">
<script>
(function(){
var step=1,parkart='',rein_a=false,rein_i=false,payOpt='';
var pF=+document.getElementById('tvd_pF').value,pP=+document.getElementById('tvd_pP').value,pRA=+document.getElementById('tvd_pRA').value,pRI=+document.getElementById('tvd_pRI').value;
document.querySelectorAll('.tvd-parkart-opt').forEach(function(el){el.addEventListener('click',function(){parkart=this.dataset.val;document.querySelectorAll('.tvd-parkart-opt').forEach(function(e){e.style.borderColor='#2a3550';e.style.background='#1e2940';e.querySelector('input').checked=false;});this.style.borderColor='#c9a84c';this.style.background='rgba(201,168,76,.08)';this.querySelector('input').checked=true;calcPrice();});});
document.querySelectorAll('.tvd-rein-opt').forEach(function(el){el.addEventListener('click',function(){var cb=this.querySelector('input');cb.checked=!cb.checked;if(this.dataset.val==='aussen')rein_a=cb.checked;else rein_i=cb.checked;var box=this.querySelector('.tvd-checkbox-box');if(cb.checked){this.style.borderColor='#c9a84c';this.style.background='rgba(201,168,76,.08)';box.style.background='#c9a84c';box.style.borderColor='#c9a84c';box.innerHTML='<span style="color:#fff;font-size:10px;font-weight:700;">✓</span>';}else{this.style.borderColor='#2a3550';this.style.background='#1e2940';box.style.background='transparent';box.style.borderColor='#4a5568';box.innerHTML='';}updateKeine();calcPrice();});});
document.querySelector('.tvd-keine-rein').addEventListener('click',function(){rein_a=false;rein_i=false;document.querySelectorAll('.tvd-rein-opt').forEach(function(el){el.querySelector('input').checked=false;el.style.borderColor='#2a3550';el.style.background='#1e2940';var b=el.querySelector('.tvd-checkbox-box');b.style.background='transparent';b.style.borderColor='#4a5568';b.innerHTML='';});updateKeine();calcPrice();});
function updateKeine(){var k=document.querySelector('.tvd-keine-rein');if(!rein_a&&!rein_i){k.style.borderColor='#c9a84c';k.style.background='rgba(201,168,76,.08)';}else{k.style.borderColor='#2a3550';k.style.background='#1e2940';}}
function calcPrice(){var a=document.getElementById('tvd_anreise').value,b=document.getElementById('tvd_abreise').value,days=0;if(a&&b){var d=(new Date(b)-new Date(a))/864e5;days=d>0?Math.round(d):0;}var pd=parkart==='freifl\u00e4che'?pF:(parkart==='parkhaus'?pP:0);var total=(days*pd+(rein_a?pRA:0)+(rein_i?pRI:0))/100;document.getElementById('tvd_days_display').textContent=days;document.getElementById('tvd_price_display').textContent=total.toFixed(2);return{days:days,total:total};}
document.getElementById('tvd_anreise').addEventListener('change',calcPrice);document.getElementById('tvd_abreise').addEventListener('change',calcPrice);
document.querySelectorAll('.tvd-pay-opt').forEach(function(el){el.addEventListener('click',function(){payOpt=this.dataset.val;document.querySelectorAll('.tvd-pay-opt').forEach(function(e){e.style.borderColor='#2a3550';e.style.background='#1e2940';e.querySelector('input').checked=false;var d=e.querySelector('.tvd-pay-dot');d.style.background='transparent';d.style.borderColor='#4a5568';d.innerHTML='';});this.style.borderColor='#c9a84c';this.style.background='rgba(201,168,76,.08)';this.querySelector('input').checked=true;var d=this.querySelector('.tvd-pay-dot');d.style.background='#c9a84c';d.style.borderColor='#c9a84c';d.innerHTML='<span style="width:8px;height:8px;border-radius:50%;background:#fff;display:block;"></span>';});});
window.tvdNextStep=function(dir){var next=step+dir;if(dir>0){if(step===1){if(!document.getElementById('tvd_anreise').value||!document.getElementById('tvd_abreise').value){alert('Bitte Datum angeben.');return;}if(!parkart){alert('Bitte Stellplatz w\u00e4hlen.');return;}}if(step===2){var r=['tvd_vorname','tvd_nachname','tvd_email','tvd_telefon','tvd_kennzeichen','tvd_modell'];for(var i=0;i<r.length;i++){if(!document.getElementById(r[i]).value.trim()){alert('Pflichtfelder ausf\u00fcllen.');return;}}}if(step===3){buildSummary();}}document.getElementById('tvd-step-'+step).style.display='none';step=next;document.getElementById('tvd-step-'+step).style.display='block';updateBar();};
function buildSummary(){var p=calcPrice();var rein=[];if(rein_a)rein.push('Au\u00dfenreinigung');if(rein_i)rein.push('Innenreinigung');if(!rein.length)rein.push('Keine');var rows=[['Anreise',document.getElementById('tvd_anreise').value+' um '+document.getElementById('tvd_ankunft').value],['Abreise',document.getElementById('tvd_abreise').value+' um '+document.getElementById('tvd_lande').value],['Stellplatz',parkart==='freifl\u00e4che'?'Freifl\u00e4che':'Parkhaus'],['Dauer',p.days+' Tage'],['Reinigung',rein.join(' + ')],['Name',document.getElementById('tvd_vorname').value+' '+document.getElementById('tvd_nachname').value],['E-Mail',document.getElementById('tvd_email').value],['Tel.',document.getElementById('tvd_telefon').value],['Kennzeichen',document.getElementById('tvd_kennzeichen').value],['Fahrzeug',document.getElementById('tvd_modell').value]];var html=rows.map(function(r){return'<div style="display:flex;justify-content:space-between;border-bottom:1px solid #2a3550;padding:6px 0;"><span style="color:#6b7280;">'+r[0]+'</span><span style="color:#e8eaf0;font-weight:500;">'+r[1]+'</span></div>';}).join('');html+='<div style="display:flex;justify-content:space-between;padding:12px 0 0;"><span style="color:#c9a84c;font-weight:700;">Gesamtpreis</span><span style="color:#c9a84c;font-weight:700;font-size:18px;">\u20ac'+p.total.toFixed(2)+'</span></div>';document.getElementById('tvd-summary').innerHTML=html;}
function updateBar(){document.querySelectorAll('.tvd-step-item').forEach(function(el){var n=+el.dataset.step;var dot=el.querySelector('.tvd-step-dot'),lbl=el.querySelector('.tvd-step-label');if(n===step){dot.style.background='linear-gradient(135deg,#c9a84c,#f0d080)';dot.style.color='#0b0f1a';lbl.style.color='#c9a84c';}else if(n<step){dot.style.background='rgba(201,168,76,.2)';dot.style.color='#c9a84c';lbl.style.color='#6b7280';}else{dot.style.background='rgba(255,255,255,.08)';dot.style.color='#6b7280';lbl.style.color='#6b7280';}});}
window.tvdSubmit=function(){if(!payOpt){alert('Zahlungsart w\u00e4hlen.');return;}if(!document.getElementById('tvd_agb').checked){alert('AGB akzeptieren.');return;}if(!document.getElementById('tvd_richtig').checked){alert('Angaben best\u00e4tigen.');return;}var btn=document.getElementById('tvd-submit-btn');btn.textContent='Wird gesendet \u2026';btn.disabled=true;var p=calcPrice();var rein=[];if(rein_a)rein.push('aussen');if(rein_i)rein.push('innen');if(!rein.length)rein.push('keine');var fd=new FormData();fd.append('action','tvd_submit_booking');fd.append('nonce',document.getElementById('tvd_nonce').value);['vorname','nachname','email','telefon','kennzeichen','modell','farbe'].forEach(function(k){fd.append(k==='modell'?'marke_modell':k,document.getElementById('tvd_'+k).value);});fd.append('anreise_datum',document.getElementById('tvd_anreise').value);fd.append('ankunftszeit',document.getElementById('tvd_ankunft').value);fd.append('abreise_datum',document.getElementById('tvd_abreise').value);fd.append('landezeit',document.getElementById('tvd_lande').value);fd.append('rueckflug',document.getElementById('tvd_rueckflug').value);fd.append('parkart',parkart);fd.append('fahrzeuglaenge',document.getElementById('tvd_laenge').value);fd.append('reinigung',rein.join('+'));fd.append('days',p.days);fd.append('price',p.total.toFixed(2));fd.append('zahlungsart',payOpt);fetch(document.getElementById('tvd_ajax_url').value,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(res){if(res.success){document.getElementById('tvd-step-4').style.display='none';document.getElementById('tvd-steps-bar').style.display='none';document.getElementById('tvd-success-pay').textContent=payOpt==='online'?'Sie erhalten eine E-Mail mit Zahlungslink.':'Zahlung in bar bei der \u00dcbergabe.';document.getElementById('tvd-success').style.display='block';}else{document.getElementById('tvd-error').style.display='block';document.getElementById('tvd-error').textContent=res.data||'Fehler.';btn.textContent='Buchung abschicken';btn.disabled=false;}}).catch(function(){document.getElementById('tvd-error').style.display='block';document.getElementById('tvd-error').textContent='Verbindungsfehler.';btn.textContent='Buchung abschicken';btn.disabled=false;});};
})();
</script>
<?php
    return ob_get_clean();
}
add_shortcode('tvd_booking_form','tvd_booking_form_shortcode');

function tvd_handle_booking(){
    if(!wp_verify_nonce($_POST['nonce']??'','tvd_booking_nonce')){wp_send_json_error('Ungültige Anfrage.');}
    global $wpdb;$t=$wpdb->prefix.'tvd_bookings';
    $d=['vorname'=>sanitize_text_field($_POST['vorname']??''),'nachname'=>sanitize_text_field($_POST['nachname']??''),'email'=>sanitize_email($_POST['email']??''),'telefon'=>sanitize_text_field($_POST['telefon']??''),'kennzeichen'=>sanitize_text_field($_POST['kennzeichen']??''),'marke_modell'=>sanitize_text_field($_POST['marke_modell']??''),'farbe'=>sanitize_text_field($_POST['farbe']??''),'anreise_datum'=>sanitize_text_field($_POST['anreise_datum']??''),'ankunftszeit'=>sanitize_text_field($_POST['ankunftszeit']??''),'abreise_datum'=>sanitize_text_field($_POST['abreise_datum']??''),'landezeit'=>sanitize_text_field($_POST['landezeit']??''),'rueckflug'=>sanitize_text_field($_POST['rueckflug']??''),'parkart'=>sanitize_text_field($_POST['parkart']??''),'fahrzeuglaenge'=>sanitize_text_field($_POST['fahrzeuglaenge']??''),'reinigung'=>sanitize_text_field($_POST['reinigung']??''),'days'=>(int)($_POST['days']??0),'price'=>(float)($_POST['price']??0),'zahlungsart'=>sanitize_text_field($_POST['zahlungsart']??'')];
    if($wpdb->insert($t,$d)===false){wp_send_json_error('Datenbankfehler.');}
    $id=$wpdb->insert_id;tvd_mail_kunde($d,$id);tvd_mail_admin($d,$id);wp_send_json_success(['id'=>$id]);
}
add_action('wp_ajax_tvd_submit_booking','tvd_handle_booking');
add_action('wp_ajax_nopriv_tvd_submit_booking','tvd_handle_booking');

function tvd_mail_kunde($d,$id){
    $rmap=['aussen'=>'Außenreinigung','innen'=>'Innenreinigung','keine'=>'Keine'];
    $rein=implode(' + ',array_map(fn($r)=>$rmap[trim($r)]??$r,explode('+',$d['reinigung'])));
    $park=$d['parkart']==='freifl\u00e4che'?'Freifl\u00e4che':'Parkhaus';
    $zahl=$d['zahlungsart']==='bar'?'Bar vor Ort':'Online';
    $sub="Buchungsbestätigung #{$id} – ".(get_theme_mod('tvd_logo_text','Travel Valet')).' '.(get_theme_mod('tvd_logo_gold','Düsseldorf'));
    $body='<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="margin:0;padding:0;background:#f5f5f5;font-family:Arial,sans-serif;"><table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;padding:40px 20px;"><tr><td><table width="600" cellpadding="0" cellspacing="0" style="margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.08);"><tr><td style="background:linear-gradient(135deg,#c9a84c,#f0d080);padding:28px;"><h1 style="margin:0;font-size:20px;color:#0b0f1a;">Buchung bestätigt!</h1><p style="margin:4px 0 0;font-size:13px;color:#0b0f1a;opacity:.7;">#'.$id.'</p></td></tr><tr><td style="padding:28px;"><p style="margin:0 0 16px;font-size:14px;color:#333;">Guten Tag <strong>'.esc_html($d['vorname']).' '.esc_html($d['nachname']).'</strong>,</p><table width="100%">';
    foreach([['Anreise',$d['anreise_datum'].' um '.$d['ankunftszeit']],['Abreise',$d['abreise_datum'].' um '.$d['landezeit']],['Stellplatz',$park],['Dauer',$d['days'].' Tage'],['Reinigung',$rein],['Preis','€ '.number_format($d['price'],2)],['Zahlung',$zahl]] as $row){
        $body.='<tr><td style="padding:7px 0;color:#555;font-size:13px;border-bottom:1px solid #f0f0f0;width:40%;"><strong>'.$row[0].'</strong></td><td style="padding:7px 0;color:#333;font-size:13px;border-bottom:1px solid #f0f0f0;">'.$row[1].'</td></tr>';
    }
    $body.='</table></td></tr><tr><td style="padding:0 28px 24px;"><div style="background:#f0f7ff;border-left:4px solid #60a5fa;border-radius:4px;padding:14px;"><p style="margin:0;font-size:13px;color:#1e3a5f;"><strong>📍 Treffpunkt:</strong> Fahren Sie direkt zum Abflugterminal des Flughafens Düsseldorf (DUS). <strong>Terminal B&amp;C</strong></p></div></td></tr><tr><td style="background:#f8f8f8;padding:14px 28px;text-align:center;border-top:1px solid #e5e5e5;"><p style="margin:0;font-size:12px;color:#888;">📞 '.esc_html(get_theme_mod('tvd_phone','+49 163 9176557')).' · '.esc_html(get_theme_mod('tvd_email','info@travelvalet-dus.de')).'</p></td></tr></table></td></tr></table></body></html>';
    wp_mail($d['email'],$sub,$body,['Content-Type: text/html; charset=UTF-8','From: '.(get_theme_mod('tvd_logo_text','Travel Valet')).' <'.get_option('tvd_smtp_from',get_option('admin_email')).'>']);
}
function tvd_mail_admin($d,$id){
    wp_mail(get_option('tvd_admin_email',get_option('admin_email')),"Neue Buchung #{$id} – {$d['vorname']} {$d['nachname']}","Buchung #{$id}
Name: {$d['vorname']} {$d['nachname']}
Email: {$d['email']}
Tel: {$d['telefon']}
Anreise: {$d['anreise_datum']}
Abreise: {$d['abreise_datum']}
Parkart: {$d['parkart']}
Reinigung: {$d['reinigung']}
Preis: €{$d['price']}");
}

function tvd_admin_menu(){
    add_menu_page('TVD Buchungen','🚗 Buchungen','manage_options','tvd-bookings','tvd_bookings_page','',30);
    add_submenu_page('tvd-bookings','Einstellungen','Einstellungen','manage_options','tvd-settings','tvd_settings_page');
}
add_action('admin_menu','tvd_admin_menu');

function tvd_bookings_page(){
    global $wpdb;$t=$wpdb->prefix.'tvd_bookings';$rows=$wpdb->get_results("SELECT * FROM $t ORDER BY created_at DESC");
    $rmap=['aussen'=>'Außenreinigung','innen'=>'Innenreinigung','keine'=>'Keine'];
    echo '<div class="wrap"><h1>🚗 Buchungen ('.count($rows).')</h1><table class="widefat striped" style="margin-top:12px;"><thead><tr><th>#</th><th>Name</th><th>E-Mail</th><th>Tel.</th><th>Anreise</th><th>Abreise</th><th>Tage</th><th>Parkart</th><th>Reinigung</th><th>Preis</th><th>Zahlung</th><th>Datum</th></tr></thead><tbody>';
    foreach($rows as $b){$rein=implode('+',array_map(fn($r)=>$rmap[trim($r)]??$r,explode('+',$b->reinigung)));echo '<tr><td>#'.$b->id.'</td><td>'.esc_html($b->vorname.' '.$b->nachname).'<br><small>'.esc_html($b->kennzeichen).'</small></td><td>'.esc_html($b->email).'</td><td>'.esc_html($b->telefon).'</td><td>'.esc_html($b->anreise_datum).'</td><td>'.esc_html($b->abreise_datum).'</td><td>'.$b->days.'</td><td>'.esc_html($b->parkart).'</td><td>'.$rein.'</td><td><strong>€'.number_format($b->price,2).'</strong></td><td>'.esc_html($b->zahlungsart).'</td><td style="font-size:11px;">'.date('d.m.Y H:i',strtotime($b->created_at)).'</td></tr>';}
    echo '</tbody></table></div>';
}
function tvd_settings_page(){
    if(isset($_POST['tvd_save'])&&check_admin_referer('tvd_settings_nonce')){update_option('tvd_price_freiflaeche',(int)(floatval($_POST['tvd_pf']??12)*100));update_option('tvd_price_parkhaus',(int)(floatval($_POST['tvd_pp']??15)*100));update_option('tvd_price_reinigung_aussen',(int)(floatval($_POST['tvd_pra']??40)*100));update_option('tvd_price_reinigung_innen',(int)(floatval($_POST['tvd_pri']??70)*100));update_option('tvd_admin_email',sanitize_email($_POST['tvd_ae']??''));update_option('tvd_smtp_from',sanitize_email($_POST['tvd_sf']??''));echo '<div class="notice notice-success"><p>✅ Gespeichert!</p></div>';}
    $pf=get_option('tvd_price_freiflaeche',1200)/100;$pp=get_option('tvd_price_parkhaus',1500)/100;$pra=get_option('tvd_price_reinigung_aussen',4000)/100;$pri=get_option('tvd_price_reinigung_innen',7000)/100;
    echo '<div class="wrap"><h1>⚙️ Einstellungen</h1><p>Für Texte, Bilder und Farben: <strong>Design → Customizer</strong></p><hr><form method="post">'.wp_nonce_field('tvd_settings_nonce','_wpnonce',true,false);
    echo '<h2>🅿️ Parkpreise</h2><table class="form-table"><tr><th>Freifläche (€/Tag)</th><td><input type="number" step="0.01" name="tvd_pf" value="'.$pf.'" class="regular-text"></td></tr><tr><th>Parkhaus (€/Tag)</th><td><input type="number" step="0.01" name="tvd_pp" value="'.$pp.'" class="regular-text"></td></tr><tr><th>Außenreinigung (€)</th><td><input type="number" step="0.01" name="tvd_pra" value="'.$pra.'" class="regular-text"></td></tr><tr><th>Innenreinigung (€)</th><td><input type="number" step="0.01" name="tvd_pri" value="'.$pri.'" class="regular-text"></td></tr></table>';
    echo '<h2>📧 E-Mail</h2><table class="form-table"><tr><th>Admin-E-Mail</th><td><input type="email" name="tvd_ae" value="'.get_option('tvd_admin_email',get_option('admin_email')).'" class="regular-text"></td></tr><tr><th>Absender-E-Mail</th><td><input type="email" name="tvd_sf" value="'.get_option('tvd_smtp_from',get_option('admin_email')).'" class="regular-text"><p class="description">Tipp: WP Mail SMTP Plugin installieren.</p></td></tr></table>';
    echo '<p class="submit"><input type="submit" name="tvd_save" class="button-primary" value="💾 Speichern"></p></form></div>';
}