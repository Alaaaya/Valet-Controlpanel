document.addEventListener('DOMContentLoaded',function(){
  var t=document.getElementById('tvd-nav-toggle'),m=document.getElementById('tvd-mobile-menu');
  if(t&&m){t.addEventListener('click',function(){m.style.display=m.style.display==='flex'?'none':'flex';});m.querySelectorAll('a').forEach(function(a){a.addEventListener('click',function(){m.style.display='none';});});}
  document.querySelectorAll('a[href^="#"]').forEach(function(a){a.addEventListener('click',function(e){var t=document.querySelector(this.getAttribute('href'));if(t){e.preventDefault();t.scrollIntoView({behavior:'smooth'});}});});
  var obs=new IntersectionObserver(function(entries){entries.forEach(function(e){if(e.isIntersecting)e.target.classList.add('show');});},{threshold:0.1});
  document.querySelectorAll('.reveal,.tvd-stat,.tvd-service-card,.tvd-step').forEach(function(el){obs.observe(el);});
});