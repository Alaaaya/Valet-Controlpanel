<footer id="tvd-footer">
  <div class="tvd-container">
    <div class="tvd-footer-grid">
      <div>
        <a href="<?php echo home_url(); ?>" class="tvd-logo">
          <?php echo tvd_mod('tvd_logo_text','Travel Valet'); ?> <span><?php echo tvd_mod('tvd_logo_gold','Düsseldorf'); ?></span>
        </a>
        <p><?php echo tvd_mod_raw('tvd_footer_text', 'Direktübergabe am Terminal. Vollkaskoversichert. 24/7 erreichbar.'); ?></p>
      </div>
      <div>
        <h4>Navigation</h4>
        <ul>
          <li><a href="<?php echo home_url('/#services'); ?>">Services</a></li>
          <li><a href="<?php echo home_url('/#ablauf'); ?>">Ablauf</a></li>
          <li><a href="<?php echo home_url('/buchen'); ?>">Buchen</a></li>
        </ul>
      </div>
      <div>
        <h4>Kontakt</h4>
        <ul>
          <li><a href="tel:<?php echo tvd_mod('tvd_phone','+49 163 9176557'); ?>">📞 <?php echo tvd_mod('tvd_phone','+49 163 9176557'); ?></a></li>
          <li><a href="https://wa.me/<?php echo tvd_mod('tvd_whatsapp','491639176557'); ?>">💬 WhatsApp</a></li>
          <li><a href="mailto:<?php echo tvd_mod('tvd_email','info@travelvalet-dus.de'); ?>">✉️ <?php echo tvd_mod('tvd_email','info@travelvalet-dus.de'); ?></a></li>
        </ul>
      </div>
    </div>
    <div class="tvd-footer-bottom">
      <div>© <?php echo date('Y'); ?> <?php echo tvd_mod('tvd_logo_text','Travel Valet'); ?> <?php echo tvd_mod('tvd_logo_gold','Düsseldorf'); ?>. Alle Rechte vorbehalten.</div>
      <div>
        <a href="<?php echo home_url('/datenschutz'); ?>">Datenschutz</a>
        <a href="<?php echo home_url('/impressum'); ?>">Impressum</a>
        <a href="<?php echo home_url('/agb'); ?>">AGB</a>
      </div>
    </div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>