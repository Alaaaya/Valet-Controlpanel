<?php
if (!defined('ABSPATH')) exit;
define('TVD_VERSION', '1.0.1');

function tvd_enqueue_scripts() {
    wp_enqueue_style('tvd-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;800&family=Inter:wght@300;400;500;600;700&display=swap', [], null);
    wp_enqueue_style('tvd-main', get_template_directory_uri() . '/js/main.css', [], TVD_VERSION);
    wp_enqueue_script('tvd-main', get_template_directory_uri() . '/js/main.js', [], TVD_VERSION, true);
}
add_action('wp_enqueue_scripts', 'tvd_enqueue_scripts');

function tvd_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', ['width' => 200, 'height' => 60, 'flex-width' => true]);
}
add_action('after_setup_theme', 'tvd_setup');
add_action('after_switch_theme', function () { flush_rewrite_rules(); });

// ─── Customizer ──────────────────────────────────────────────────────────────
function tvd_customizer($wp_customize) {

    // ── Panels ───────────────────────────────────────────────────────────────
    $wp_customize->add_panel('tvd_allgemein',  ['title' => '🌐 Allgemein & Kontakt', 'priority' => 10]);
    $wp_customize->add_panel('tvd_hero',       ['title' => '🏠 Hero-Bereich',         'priority' => 20]);
    $wp_customize->add_panel('tvd_stats',      ['title' => '📊 Statistiken',           'priority' => 30]);
    $wp_customize->add_panel('tvd_services',   ['title' => '🚗 Leistungen',            'priority' => 40]);
    $wp_customize->add_panel('tvd_ablauf',     ['title' => '📋 Ablauf (Schritte)',      'priority' => 50]);
    $wp_customize->add_panel('tvd_about',      ['title' => 'ℹ️ Über uns',              'priority' => 60]);
    $wp_customize->add_panel('tvd_footer',     ['title' => '🔻 Footer',                'priority' => 70]);

    // Helper: add text setting + control
    $add = function ($id, $label, $default, $section, $type = 'text') use ($wp_customize) {
        $wp_customize->add_setting($id, ['default' => $default, 'sanitize_callback' => 'wp_kses_post', 'transport' => 'refresh']);
        $wp_customize->add_control($id, ['label' => $label, 'section' => $section, 'type' => $type]);
    };
    $addImg = function ($id, $label, $default, $section) use ($wp_customize) {
        $wp_customize->add_setting($id, ['default' => $default, 'sanitize_callback' => 'esc_url_raw', 'transport' => 'refresh']);
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, $id, ['label' => $label, 'section' => $section]));
    };

    // ── Allgemein ─────────────────────────────────────────────────────────────
    $wp_customize->add_section('tvd_sec_allgemein', ['title' => 'Kontakt & Logo', 'panel' => 'tvd_allgemein', 'priority' => 10]);
    $add('tvd_phone',       'Telefonnummer',                '+49 163 9176557',       'tvd_sec_allgemein');
    $add('tvd_whatsapp',    'WhatsApp-Nummer (ohne +)',     '491639176557',          'tvd_sec_allgemein');
    $add('tvd_email',       'E-Mail Adresse',               'info@travelvalet-dus.de','tvd_sec_allgemein');
    $add('tvd_logo_text',   'Logo-Text (linke Seite)',      'Travel Valet',          'tvd_sec_allgemein');
    $add('tvd_logo_gold',   'Logo-Text (goldene Seite)',    'Düsseldorf',            'tvd_sec_allgemein');
    $addImg('tvd_hero_bg',  'Hero Hintergrundbild',         'https://d2xsxph8kpxj0f.cloudfront.net/310519663038360745/UuXWRhwHAUuwUjZEEfktYD/hero-background-bY6siUeWr6bJr93vNJwpVC.webp', 'tvd_sec_allgemein');
    $addImg('tvd_about_bg', 'Über-uns Hintergrundbild',     'https://d2xsxph8kpxj0f.cloudfront.net/310519663038360745/UuXWRhwHAUuwUjZEEfktYD/about-section-background-YV2SMQBzqvGT3hnsNGKEZf.webp', 'tvd_sec_allgemein');

    // ── Hero ──────────────────────────────────────────────────────────────────
    $wp_customize->add_section('tvd_sec_hero', ['title' => 'Hero Texte & Buttons', 'panel' => 'tvd_hero', 'priority' => 10]);
    $add('tvd_hero_badge',   'Badge-Text',          '✦ Premium Valet Service · Düsseldorf DUS', 'tvd_sec_hero');
    $add('tvd_hero_title1',  'Überschrift Zeile 1', 'Parken am Flughafen',                      'tvd_sec_hero');
    $add('tvd_hero_title2',  'Überschrift Zeile 2 (gold)', 'ohne jeden Stress',                 'tvd_sec_hero');
    $add('tvd_hero_subtitle','Untertitel',           'Wir übernehmen Ihr Fahrzeug direkt am Terminal – sicher, direkt und zuverlässig. Sie steigen aus, wir parken. So einfach ist das.', 'tvd_sec_hero', 'textarea');
    $add('tvd_hero_btn1',    'Button 1 Text',        'Jetzt buchen →',             'tvd_sec_hero');
    $add('tvd_hero_btn2',    'Button 2 Text',        '💬 WhatsApp buchen',         'tvd_sec_hero');
    $add('tvd_hero_btn3',    'Button 3 Text',        '📞 Direkt anrufen',          'tvd_sec_hero');

    // ── Stats ─────────────────────────────────────────────────────────────────
    foreach ([1,2,3,4] as $i) {
        $defaults = [1=>['24/7','Verfügbarkeit'],2=>['5★','Kundenbewertung'],3=>['2min','Übergabezeit'],4=>['100%','Vollkaskoversichert']];
        $wp_customize->add_section("tvd_sec_stat{$i}", ['title' => "Statistik {$i}", 'panel' => 'tvd_stats', 'priority' => $i * 10]);
        $add("tvd_stat{$i}_val", 'Zahl / Wert',  $defaults[$i][0], "tvd_sec_stat{$i}");
        $add("tvd_stat{$i}_lbl", 'Bezeichnung',  $defaults[$i][1], "tvd_sec_stat{$i}");
    }

    // ── Services ──────────────────────────────────────────────────────────────
    $svc_defaults = [
        1 => ['🚘', 'Premium-Abgabe',       'Fahren Sie direkt zum Abflugterminal B–C. Unser Mitarbeiter erstellt ein Übergabeprotokoll und übernimmt Ihr Fahrzeug.'],
        2 => ['⚡', 'Express-Abholung',     'Nach der Landung einfach anrufen. Ihr Fahrzeug steht in wenigen Minuten vor dem Terminal – kein Shuttle, keine langen Wege.'],
        3 => ['🔒', 'Sichere Parkanlage',   'Videoüberwacht, zugangskontrolliert. Vollkaskoversicherung für die gesamte Standzeit inklusive.'],
        4 => ['🤍', 'Sorgfältige Handhabung','Nur geschulte Mitarbeiter bewegen Ihre Fahrzeuge nach klaren Protokollen.'],
    ];
    foreach ($svc_defaults as $i => $s) {
        $wp_customize->add_section("tvd_sec_svc{$i}", ['title' => "Leistung {$i}: {$s[1]}", 'panel' => 'tvd_services', 'priority' => $i * 10]);
        $add("tvd_svc{$i}_icon",  'Icon (Emoji)',  $s[0],  "tvd_sec_svc{$i}");
        $add("tvd_svc{$i}_title", 'Titel',         $s[1],  "tvd_sec_svc{$i}");
        $add("tvd_svc{$i}_desc",  'Beschreibung',  $s[2],  "tvd_sec_svc{$i}", 'textarea');
    }

    // ── Ablauf ────────────────────────────────────────────────────────────────
    $step_defaults = [
        1 => ['Online buchen',         'Reisedaten eingeben, Parkart wählen und absenden. Bestätigung kommt in wenigen Minuten.'],
        2 => ['Ankunft am Terminal',    'Zur vereinbarten Zeit direkt zum Terminal B–C vorfahren. Mitarbeiter übernimmt nach Protokoll.'],
        3 => ['Sicheres Parken',        'Überdachte, videoüberwachte Anlage. Vollkaskoversichert für die gesamte Reisedauer.'],
        4 => ['Entspannte Rückkehr',    'Kurz anrufen nach der Gepäckausgabe – Ihr Auto steht in Minuten startklar am Terminal.'],
    ];
    foreach ($step_defaults as $i => $s) {
        $wp_customize->add_section("tvd_sec_step{$i}", ['title' => "Schritt {$i}: {$s[0]}", 'panel' => 'tvd_ablauf', 'priority' => $i * 10]);
        $add("tvd_step{$i}_title", 'Titel',        $s[0], "tvd_sec_step{$i}");
        $add("tvd_step{$i}_desc",  'Beschreibung', $s[1], "tvd_sec_step{$i}", 'textarea');
    }

    // ── Über uns ──────────────────────────────────────────────────────────────
    $wp_customize->add_section('tvd_sec_about', ['title' => 'Über uns Texte', 'panel' => 'tvd_about', 'priority' => 10]);
    $add('tvd_about_title', 'Überschrift',   'Ihr persönlicher<br>Parkservice in Düsseldorf', 'tvd_sec_about');
    $add('tvd_about_p1',    'Absatz 1',      'Travel Valet Düsseldorf steht für komfortables, sicheres und preislich attraktives Valet Parking am Flughafen Düsseldorf (DUS).', 'tvd_sec_about', 'textarea');
    $add('tvd_about_p2',    'Absatz 2',      'Unser Service richtet sich an Reisende aus Düsseldorf, Neuss, Ratingen, Duisburg, Krefeld, Meerbusch und der gesamten Region.', 'tvd_sec_about', 'textarea');
    $check_defaults = [
        1 => 'Fahrzeugübergabe direkt am Terminal – kein Umweg, kein Stress',
        2 => 'Überdachte, videoüberwachte Stellplätze nahe des Flughafens',
        3 => 'Vollkaskoversicherung für die gesamte Standzeit inklusive',
        4 => '24/7 erreichbar per Telefon, WhatsApp oder E-Mail',
        5 => 'Transparente Preise ohne versteckte Zusatzkosten',
    ];
    foreach ($check_defaults as $i => $txt) {
        $add("tvd_check{$i}", "Punkt {$i}", $txt, 'tvd_sec_about', 'textarea');
    }
    $add('tvd_about_btn', 'Button Text', 'Jetzt Stellplatz sichern →', 'tvd_sec_about');

    // ── Footer ────────────────────────────────────────────────────────────────
    $wp_customize->add_section('tvd_sec_footer', ['title' => 'Footer Texte', 'panel' => 'tvd_footer', 'priority' => 10]);
    $add('tvd_footer_text', 'Beschreibungstext', 'Direktübergabe am Terminal. Vollkaskoversichert. 24/7 erreichbar.', 'tvd_sec_footer', 'textarea');

    // ── Buchungs-Abschnitt ────────────────────────────────────────────────────
    $wp_customize->add_section('tvd_sec_booking', ['title' => '📅 Buchungs-Abschnitt', 'priority' => 65]);
    $add('tvd_booking_title',    'Überschrift',   'Jetzt Parkplatz buchen',                         'tvd_sec_booking');
    $add('tvd_booking_subtitle', 'Untertitel',    'Sicher, direkt am Terminal — in wenigen Schritten.', 'tvd_sec_booking');

    // ── Farben ────────────────────────────────────────────────────────────────
    $wp_customize->add_section('tvd_sec_colors', ['title' => '🎨 Farben', 'priority' => 80]);
    $color_settings = [
        'tvd_color_gold'   => ['Gold (Hauptakzent)',    '#eab308'],
        'tvd_color_gold2'  => ['Gold dunkel (Hover)',   '#ca8a04'],
        'tvd_color_bg'     => ['Hintergrund (hell)',    '#f8f8f8'],
    ];
    foreach ($color_settings as $id => [$label, $default]) {
        $wp_customize->add_setting($id, ['default' => $default, 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'refresh']);
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, $id, ['label' => $label, 'section' => 'tvd_sec_colors']));
    }
}
add_action('customize_register', 'tvd_customizer');

// ─── Helper: theme_mod with fallback ─────────────────────────────────────────
function tvd_mod($key, $default = '') {
    return esc_html(get_theme_mod($key, $default));
}
function tvd_mod_raw($key, $default = '') {
    return wp_kses_post(get_theme_mod($key, $default));
}
