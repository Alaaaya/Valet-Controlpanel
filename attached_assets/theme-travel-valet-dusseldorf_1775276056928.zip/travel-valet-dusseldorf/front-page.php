<?php get_header(); ?>

<!-- HERO -->
<section id="home" class="tvd-hero" style="background-image:url('<?php echo esc_url(get_theme_mod('tvd_hero_bg','https://d2xsxph8kpxj0f.cloudfront.net/310519663038360745/UuXWRhwHAUuwUjZEEfktYD/hero-background-bY6siUeWr6bJr93vNJwpVC.webp')); ?>');">
  <div class="tvd-hero-overlay"></div>
  <div class="tvd-hero-content">
    <div class="tvd-badge"><?php echo tvd_mod('tvd_hero_badge','✦ Premium Valet Service · Düsseldorf DUS'); ?></div>
    <h1>
      <?php echo tvd_mod('tvd_hero_title1','Parken am Flughafen'); ?><br>
      <span class="tvd-gold"><?php echo tvd_mod('tvd_hero_title2','ohne jeden Stress'); ?></span>
    </h1>
    <p><?php echo tvd_mod_raw('tvd_hero_subtitle','Wir übernehmen Ihr Fahrzeug direkt am Terminal – sicher, direkt und zuverlässig. Sie steigen aus, wir parken. So einfach ist das.'); ?></p>
    <div class="tvd-hero-btns">
      <a href="#buchen" class="tvd-btn-gold"><?php echo tvd_mod('tvd_hero_btn1','Jetzt buchen →'); ?></a>
      <a href="https://wa.me/<?php echo tvd_mod('tvd_whatsapp','491639176557'); ?>" class="tvd-btn-green" target="_blank"><?php echo tvd_mod('tvd_hero_btn2','💬 WhatsApp buchen'); ?></a>
      <a href="tel:<?php echo tvd_mod('tvd_phone','+49 163 9176557'); ?>" class="tvd-btn-outline"><?php echo tvd_mod('tvd_hero_btn3','📞 Direkt anrufen'); ?></a>
    </div>
  </div>
</section>

<!-- STATS -->
<div class="tvd-stats">
  <?php for($i=1;$i<=4;$i++): ?>
  <div class="tvd-stat">
    <div class="tvd-stat-num"><?php echo tvd_mod("tvd_stat{$i}_val"); ?></div>
    <div class="tvd-stat-lbl"><?php echo tvd_mod("tvd_stat{$i}_lbl"); ?></div>
  </div>
  <?php endfor; ?>
</div>

<!-- SERVICES -->
<section id="services" class="tvd-section tvd-bg-light">
  <div class="tvd-container">
    <div class="tvd-section-header">
      <div class="tvd-badge">Leistungen</div>
      <h2>Unser Premium-Service<br>im Überblick</h2>
    </div>
    <div class="tvd-services-grid">
      <?php for($i=1;$i<=4;$i++): ?>
      <div class="tvd-service-card reveal">
        <div class="tvd-service-icon"><?php echo tvd_mod("tvd_svc{$i}_icon"); ?></div>
        <h3><?php echo tvd_mod("tvd_svc{$i}_title"); ?></h3>
        <p><?php echo tvd_mod_raw("tvd_svc{$i}_desc"); ?></p>
      </div>
      <?php endfor; ?>
    </div>
  </div>
</section>

<!-- HOW IT WORKS -->
<section id="ablauf" class="tvd-section">
  <div class="tvd-container">
    <div class="tvd-section-header">
      <div class="tvd-badge">Ablauf</div>
      <h2>So einfach funktioniert's</h2>
    </div>
    <div class="tvd-steps-grid">
      <?php for($i=1;$i<=4;$i++): ?>
      <div class="tvd-step reveal">
        <div class="tvd-step-num"><?php echo $i; ?></div>
        <h3><?php echo tvd_mod("tvd_step{$i}_title"); ?></h3>
        <p><?php echo tvd_mod_raw("tvd_step{$i}_desc"); ?></p>
      </div>
      <?php endfor; ?>
    </div>
  </div>
</section>

<!-- BOOKING -->
<section id="buchen" class="tvd-section tvd-bg-light">
  <div class="tvd-container">
    <div class="tvd-section-header" style="text-align:center;">
      <div class="tvd-badge">✦ Travel Valet · Düsseldorf DUS</div>
      <h2><?php echo tvd_mod('tvd_booking_title','Jetzt Parkplatz buchen'); ?></h2>
      <p><?php echo tvd_mod('tvd_booking_subtitle','Sicher, direkt am Terminal — in wenigen Schritten.'); ?></p>
    </div>
    <div class="tvd-form-wrap">
      <?php echo do_shortcode('[tvd_booking_form]'); ?>
    </div>
  </div>
</section>

<!-- ABOUT -->
<section id="ueber-uns" class="tvd-about">
  <div class="tvd-about-img" style="background-image:url('<?php echo esc_url(get_theme_mod('tvd_about_bg','https://d2xsxph8kpxj0f.cloudfront.net/310519663038360745/UuXWRhwHAUuwUjZEEfktYD/about-section-background-YV2SMQBzqvGT3hnsNGKEZf.webp')); ?>');">
    <div class="tvd-about-deco">DUS</div>
  </div>
  <div class="tvd-about-text">
    <div class="tvd-badge">Über uns</div>
    <h2><?php echo tvd_mod_raw('tvd_about_title','Ihr persönlicher<br>Parkservice in Düsseldorf'); ?></h2>
    <p><?php echo tvd_mod_raw('tvd_about_p1','Travel Valet Düsseldorf steht für komfortables, sicheres und preislich attraktives Valet Parking am Flughafen Düsseldorf (DUS).'); ?></p>
    <p><?php echo tvd_mod_raw('tvd_about_p2','Unser Service richtet sich an Reisende aus Düsseldorf, Neuss, Ratingen, Duisburg, Krefeld, Meerbusch und der gesamten Region.'); ?></p>
    <ul class="tvd-checklist">
      <?php for($i=1;$i<=5;$i++): $t = get_theme_mod("tvd_check{$i}"); if($t): ?>
      <li><?php echo esc_html($t); ?></li>
      <?php endif; endfor; ?>
    </ul>
    <a href="#buchen" class="tvd-btn-gold"><?php echo tvd_mod('tvd_about_btn','Jetzt Stellplatz sichern →'); ?></a>
  </div>
</section>

<!-- CONTACT -->
<section id="kontakt" class="tvd-section">
  <div class="tvd-container">
    <div class="tvd-section-header">
      <div class="tvd-badge">Kontakt</div>
      <h2>Wir sind für Sie da</h2>
    </div>
    <div class="tvd-contact-grid">
      <div class="tvd-contact-cards">
        <a href="tel:<?php echo tvd_mod('tvd_phone','+49 163 9176557'); ?>" class="tvd-contact-card">
          <div class="tvd-contact-icon">📞</div>
          <div><div class="tvd-contact-lbl">Telefon</div><div class="tvd-contact-val"><?php echo tvd_mod('tvd_phone','+49 163 9176557'); ?></div></div>
        </a>
        <a href="https://wa.me/<?php echo tvd_mod('tvd_whatsapp','491639176557'); ?>" class="tvd-contact-card">
          <div class="tvd-contact-icon">💬</div>
          <div><div class="tvd-contact-lbl">WhatsApp</div><div class="tvd-contact-val">Jetzt schreiben</div></div>
        </a>
        <a href="mailto:<?php echo tvd_mod('tvd_email','info@travelvalet-dus.de'); ?>" class="tvd-contact-card">
          <div class="tvd-contact-icon">✉️</div>
          <div><div class="tvd-contact-lbl">E-Mail</div><div class="tvd-contact-val"><?php echo tvd_mod('tvd_email','info@travelvalet-dus.de'); ?></div></div>
        </a>
        <div class="tvd-contact-card">
          <div class="tvd-contact-icon">📍</div>
          <div><div class="tvd-contact-lbl">Standort</div><div class="tvd-contact-val">Flughafen Düsseldorf (DUS)</div></div>
        </div>
      </div>
      <form class="tvd-contact-form" onsubmit="return false;">
        <div class="tvd-field"><label>Name</label><input type="text" placeholder="Ihr Name"></div>
        <div class="tvd-field"><label>E-Mail</label><input type="email" placeholder="Ihre E-Mail"></div>
        <div class="tvd-field"><label>Nachricht</label><textarea rows="5" placeholder="Ihre Nachricht …"></textarea></div>
        <button type="submit" class="tvd-btn-gold tvd-full">Nachricht senden →</button>
      </form>
    </div>
  </div>
</section>

<?php get_footer(); ?>