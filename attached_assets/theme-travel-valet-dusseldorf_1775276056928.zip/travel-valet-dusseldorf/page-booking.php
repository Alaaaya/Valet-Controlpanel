<?php get_header(); ?>
<div class="tvd-booking-page">
  <div class="tvd-container">
    <div class="tvd-section-header" style="text-align:center;">
      <div class="tvd-badge">✦ Travel Valet · Düsseldorf DUS</div>
      <h1><?php echo tvd_mod('tvd_booking_title','Jetzt Parkplatz buchen'); ?></h1>
      <p><?php echo tvd_mod('tvd_booking_subtitle','Sicher, direkt am Terminal — in wenigen Schritten.'); ?></p>
    </div>
    <div class="tvd-form-wrap">
      <?php echo do_shortcode('[tvd_booking_form]'); ?>
    </div>
  </div>
</div>
<?php get_footer(); ?>