<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  :root {
    --tvd-gold:  <?php echo esc_attr(get_theme_mod('tvd_color_gold',  '#eab308')); ?>;
    --tvd-gold2: <?php echo esc_attr(get_theme_mod('tvd_color_gold2', '#ca8a04')); ?>;
    --tvd-bg:    <?php echo esc_attr(get_theme_mod('tvd_color_bg',    '#f8f8f8')); ?>;
  }
</style>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<nav id="tvd-nav">
  <a href="<?php echo home_url(); ?>" class="tvd-logo">
    <?php echo tvd_mod('tvd_logo_text', 'Travel Valet'); ?>
    <span> <?php echo tvd_mod('tvd_logo_gold', 'Düsseldorf'); ?></span>
  </a>
  <div class="tvd-nav-links">
    <a href="<?php echo home_url('/#services'); ?>">Services</a>
    <a href="<?php echo home_url('/#ablauf'); ?>">Ablauf</a>
    <a href="<?php echo home_url('/#ueber-uns'); ?>">Über uns</a>
    <a href="<?php echo home_url('/#kontakt'); ?>">Kontakt</a>
    <a href="<?php echo home_url('/buchen'); ?>" class="tvd-btn-gold">Jetzt Buchen</a>
  </div>
  <button id="tvd-nav-toggle" aria-label="Menü"><span></span><span></span><span></span></button>
</nav>
<div id="tvd-mobile-menu">
  <a href="<?php echo home_url('/#services'); ?>">Services</a>
  <a href="<?php echo home_url('/#ablauf'); ?>">Ablauf</a>
  <a href="<?php echo home_url('/#ueber-uns'); ?>">Über uns</a>
  <a href="<?php echo home_url('/#kontakt'); ?>">Kontakt</a>
  <a href="<?php echo home_url('/buchen'); ?>" class="tvd-btn-gold" style="margin-top:10px;text-align:center;border-radius:8px;">Jetzt Buchen</a>
</div>